"""SSP partition and configuration definitions."""

from clusterx.utils import StrEnum


class SSPPartition(StrEnum):
    """SSP queue/partition identifiers.

    These should be configured based on the actual queues available in your SSP deployment.
    """

    # Example partitions - these should be updated based on actual SSP configuration
    DEFAULT = "default"
    GPU = "gpu"
    CPU = "cpu"
    HIGH_PRIORITY = "high-priority"
