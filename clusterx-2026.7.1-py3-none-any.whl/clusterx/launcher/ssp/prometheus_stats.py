"""Prometheus stats helpers for SSP."""

from __future__ import annotations

import base64
import json
import re
from datetime import datetime, timedelta, timezone
from pathlib import Path
from typing import Any


QUERY_TOKEN_CACHE_DIR = Path.home() / ".config" / "clusterx" / "ssp_query_tokens"

SSP_STATS_METRICS = {
    "gpu-util": {
        "query": "avg by (Hostname) (avg_over_time(lepton__ssp__gpu_util{labels}[{minutes}m]))",
        "title": "GPU Util Avg %",
        "unit": "%",
    },
    "gpu-memory-util": {
        "query": (
            "100 * avg by (Hostname) (avg_over_time(lepton__ssp__gpu_memory_used__MiB{labels}[{minutes}m])) "
            "/ avg by (Hostname) (avg_over_time(lepton__ssp__gpu_memory_total__MiB{labels}[{minutes}m]))"
        ),
        "title": "GPU Memory Util Avg %",
        "unit": "%",
    },
    "gpu-power": {
        "query": "avg by (Hostname) (avg_over_time(lepton__ssp__gpu_power_usage{labels}[{minutes}m]))",
        "title": "GPU Power Avg W",
        "unit": "W",
    },
    "gpu-temp": {
        "query": "avg by (Hostname) (avg_over_time(lepton__ssp__gpu_temp{labels}[{minutes}m]))",
        "title": "GPU Temp Avg °C",
        "unit": "°C",
    },
}

SSP_STATS_SCOPES = {"workspace", "cluster", "queue", "job"}


def build_cache_path(subscription: str, resource_group: str, region: str, workspace: str) -> Path:
    key = "_".join(_sanitize_cache_part(p) for p in (subscription, resource_group, region, workspace))
    return QUERY_TOKEN_CACHE_DIR / f"{key}.json"


def _sanitize_cache_part(value: str) -> str:
    return re.sub(r"[^A-Za-z0-9_.-]+", "_", value).strip("_") or "unknown"


def decode_jwt_exp(token: str) -> datetime | None:
    parts = token.split(".")
    if len(parts) < 2:
        return None

    payload = parts[1]
    payload += "=" * (-len(payload) % 4)
    try:
        data = json.loads(base64.urlsafe_b64decode(payload.encode("ascii")))
        exp = data.get("exp")
        if exp is None:
            return None
        return datetime.fromtimestamp(float(exp), tz=timezone.utc)
    except Exception:
        return None


def is_token_valid(token: str, expire_time: str | None = None, now: datetime | None = None) -> bool:
    now = now or datetime.now(timezone.utc)
    expires_at = decode_jwt_exp(token)
    if expires_at is None and expire_time:
        expires_at = _parse_datetime(expire_time)
    if expires_at is None:
        return False

    # Keep a small margin so a nearly-expired token is refreshed before querying.
    return expires_at > now + timedelta(minutes=5)


def _parse_datetime(value: str) -> datetime | None:
    try:
        normalized = value.replace("Z", "+00:00")
        parsed = datetime.fromisoformat(normalized)
        if parsed.tzinfo is None:
            parsed = parsed.replace(tzinfo=timezone.utc)
        return parsed.astimezone(timezone.utc)
    except ValueError:
        return None


def extract_private_telemetry_rid(resources_response: dict[str, Any]) -> str:
    for resource in resources_response.get("resources", []):
        properties = resource.get("properties", {})
        if isinstance(properties, str):
            try:
                properties = json.loads(properties)
            except json.JSONDecodeError:
                properties = {}
        if properties.get("station_type") == "PRIVATE" and resource.get("rid"):
            return resource["rid"]
    raise RuntimeError("No PRIVATE telemetry station resource found")


def extract_query_token(response: dict[str, Any]) -> str:
    for key in ("query_token", "queryToken", "token", "access_token"):
        value = response.get(key)
        if isinstance(value, str) and value:
            return value
    raise RuntimeError(f"QueryToken response does not contain a token field: {response}")


def load_cached_query_token(cache_path: Path, now: datetime | None = None) -> dict[str, Any] | None:
    if not cache_path.exists():
        return None
    try:
        with cache_path.open("r") as f:
            data = json.load(f)
    except (OSError, json.JSONDecodeError):
        return None

    token = data.get("query_token")
    if not isinstance(token, str):
        return None
    if not is_token_valid(token, data.get("expire_time"), now=now):
        return None
    return data


def get_query_token(client: Any, cache_path: Path | None = None, now: datetime | None = None) -> dict[str, Any]:
    cache_path = cache_path or build_cache_path(
        client.subscription,
        client.resource_group,
        client.region,
        client.workspace,
    )
    cached = load_cached_query_token(cache_path, now=now)
    if cached is not None:
        return cached

    workspace = client.get_workspace()
    workspace_uid = workspace.get("uid")
    if not workspace_uid:
        raise RuntimeError(f"Workspace response does not contain uid: {workspace}")

    telemetry_rid = extract_private_telemetry_rid(client.list_telemetry_stations())
    expire_time = ((now or datetime.now(timezone.utc)) + timedelta(days=90)).replace(microsecond=0).isoformat()
    expire_time = expire_time.replace("+00:00", "Z")
    token_response = client.create_query_token(telemetry_rid, workspace_uid, expire_time)
    query_token = extract_query_token(token_response)

    data = {
        "query_token": query_token,
        "workspace_uid": workspace_uid,
        "rid": telemetry_rid,
        "expire_time": token_response.get("expire_time") or expire_time,
        "created_at": (now or datetime.now(timezone.utc)).replace(microsecond=0).isoformat().replace("+00:00", "Z"),
    }
    cache_path.parent.mkdir(parents=True, exist_ok=True)
    with cache_path.open("w") as f:
        json.dump(data, f, indent=2)
    return data


def resolve_metric_keys(metric: str) -> list[str]:
    if metric == "all":
        return list(SSP_STATS_METRICS)
    if metric not in SSP_STATS_METRICS:
        valid = ", ".join([*SSP_STATS_METRICS, "all"])
        raise ValueError(f"Unsupported metric: {metric}. Valid values: {valid}")
    return [metric]


def build_scope_labels(
    *,
    scope: str,
    workspace: str,
    cluster: str | None = None,
    queue: str | None = None,
    job: str | None = None,
) -> dict[str, str]:
    if scope not in SSP_STATS_SCOPES:
        valid = ", ".join(sorted(SSP_STATS_SCOPES))
        raise ValueError(f"Unsupported scope: {scope}. Valid values: {valid}")

    labels = {
        "label_resource_compute_sensecore_cn_workspace_name": workspace,
    }
    if scope in {"cluster", "queue", "job"}:
        if not cluster:
            raise ValueError("Cluster name is required for cluster/queue/job stats")
        labels["label_resource_compute_sensecore_cn_cluster_name"] = cluster
    if scope in {"queue", "job"}:
        if not queue:
            raise ValueError("Queue name is required for queue/job stats")
        labels["label_resource_compute_sensecore_cn_queue_name"] = queue
    if scope == "job":
        if not job:
            raise ValueError("Job name is required for job stats")
        labels["label_resource_compute_sensecore_cn_workload_type"] = "training-job"
        labels["label_resource_compute_sensecore_cn_workload_name"] = job
    return labels


def build_promql(metric_key: str, labels: dict[str, str], minutes: int) -> str:
    if minutes <= 0:
        raise ValueError("--minutes must be greater than 0")
    label_selector = ",".join(f'{key}="{_escape_label_value(value)}"' for key, value in labels.items())
    return SSP_STATS_METRICS[metric_key]["query"].format(labels=f"{{{label_selector}}}", minutes=minutes)


def _escape_label_value(value: str) -> str:
    return value.replace("\\", "\\\\").replace('"', '\\"')


def parse_prometheus_vector(response: dict[str, Any]) -> dict[str, float]:
    if response.get("status") not in (None, "success"):
        error = response.get("error") or response.get("errorType") or response
        raise RuntimeError(f"Prometheus query failed: {error}")

    data = response.get("data", {})
    rows: dict[str, float] = {}
    for item in data.get("result", []):
        metric = item.get("metric", {})
        hostname = metric.get("Hostname") or metric.get("hostname") or metric.get("node_name")
        value = item.get("value", [])
        if not hostname or len(value) < 2:
            continue
        try:
            rows[hostname] = float(value[1])
        except (TypeError, ValueError):
            continue
    return rows


def merge_metric_rows(metric_values: dict[str, dict[str, float]]) -> list[dict[str, Any]]:
    hostnames = sorted({hostname for values in metric_values.values() for hostname in values})
    rows = []
    for hostname in hostnames:
        row: dict[str, Any] = {"hostname": hostname}
        for metric_key in metric_values:
            row[metric_key] = metric_values[metric_key].get(hostname)
        rows.append(row)
    return rows
