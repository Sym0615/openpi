"""SSP AKSK authentication utilities."""

import hmac
import hashlib
import base64
from datetime import datetime, timezone
from typing import Dict


def generate_ssp_signature(
    ak_id: str,
    ak_secret: str,
    method: str,
    path: str,
    host: str,
    date: str | None = None,
) -> tuple[str, str]:
    """Generate SSP AKSK signature headers.

    Args:
        ak_id: Access key ID
        ak_secret: Access key secret
        method: HTTP method (GET, POST, etc.)
        path: Request path (e.g., /ait/data/v1/trainingJobs)
        host: Host header value
        date: Date string in RFC 1123 format (optional)

    Returns:
        Tuple of (date, authorization_header)
    """
    if date is None:
        date = datetime.now(timezone.utc).strftime("%a, %d %b %Y %H:%M:%S GMT")

    # Build signing content
    signing_content = f"date: {date}\nhost: {host}\n@request-target: {method.lower()} {path}"

    # Generate HMAC-SHA256 signature
    signature = hmac.new(
        ak_secret.encode("utf-8"),
        signing_content.encode("utf-8"),
        hashlib.sha256,
    ).digest()

    # Base64 encode
    signature_b64 = base64.b64encode(signature).decode("utf-8")

    # Build authorization header
    authorization = (
        f'hmac accesskey="{ak_id}", algorithm="hmac-sha256", '
        f'headers="date host @request-target", signature="{signature_b64}"'
    )

    return date, authorization


def get_auth_headers(
    ak_id: str,
    ak_secret: str,
    method: str,
    path: str,
    host: str,
) -> Dict[str, str]:
    """Get complete authentication headers for SSP API request.

    Args:
        ak_id: Access key ID
        ak_secret: Access key secret
        method: HTTP method
        path: Request path
        host: Host header value

    Returns:
        Dictionary containing Date and Authorization headers
    """
    date, authorization = generate_ssp_signature(ak_id, ak_secret, method, path, host)

    return {
        "Date": date,
        "Authorization": authorization,
        "Host": host,
    }
