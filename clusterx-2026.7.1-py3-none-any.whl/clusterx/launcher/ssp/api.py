"""SSP API client implementation."""

from typing import Any

import requests

from .auth import get_auth_headers


class SSPAPIClient:
    """SSP API client with AKSK authentication."""

    def __init__(
        self,
        compute_endpoint: str,
        subscription: str,
        resource_group: str,
        region: str,
        workspace: str,
        ak_id: str,
        ak_secret: str,
        management_endpoint: str | None = None,
        monitor_endpoint: str | None = None,
    ):
        self.subscription = subscription
        self.resource_group = resource_group
        self.region = region
        self.workspace = workspace
        self.ak_id = ak_id
        self.ak_secret = ak_secret

        # Two separate endpoints for different APIs
        self.compute_base_endpoint = compute_endpoint.rstrip("/")
        self.management_base_endpoint = (
            management_endpoint.rstrip("/") if management_endpoint else self.compute_base_endpoint
        )
        self.monitor_endpoint = (
            monitor_endpoint.rstrip("/") if monitor_endpoint else self.management_base_endpoint
        )
        self.compute_endpoint = f"{self.compute_base_endpoint}/ait/data/v1"
        self.management_endpoint = f"{self.management_base_endpoint}/compute/ssp/v1"

    def _get_base_path(self) -> str:
        """Get the base API path for training jobs."""
        # Returns path relative to compute_endpoint (which already includes /ait/data/v1)
        return (
            f"/subscriptions/{self.subscription}/"
            f"resourceGroups/{self.resource_group}/"
            f"regions/{self.region}/"
            f"workspaces/{self.workspace}/"
        )

    def _make_request(
        self,
        method: str,
        path: str,
        data: dict[str, Any] | None = None,
        params: dict[str, Any] | None = None,
    ) -> dict[str, Any]:
        """Make authenticated request to SSP Compute API (training jobs)."""
        from urllib.parse import urlencode, urlparse

        # Build query string
        query_string = ""
        if params:
            filtered_params = {k: v for k, v in params.items() if v is not None}
            if filtered_params:
                query_string = "?" + urlencode(filtered_params)

        # Build full URL using compute endpoint
        url = f"{self.compute_endpoint}{path}{query_string}"

        # Parse URL to extract host and path for signing
        parsed_url = urlparse(url)
        signing_path = parsed_url.path
        if parsed_url.query:
            signing_path += "?" + parsed_url.query
        host = parsed_url.netloc

        # Get authentication headers
        headers = get_auth_headers(
            ak_id=self.ak_id,
            ak_secret=self.ak_secret,
            method=method,
            path=signing_path,
            host=host,
        )

        # Make request
        response = requests.request(
            method=method,
            url=url,
            headers=headers,
            json=data,
            timeout=60,
        )
        if response.status_code >= 400:
            print(f"[API Error] {response.status_code}: {response.text}")
        response.raise_for_status()

        if response.status_code == 204:
            return {}

        return response.json() if response.text else {}

    def create_training_job(self, job_spec: dict[str, Any]) -> dict[str, Any]:
        """Create a new training job."""
        import json
        print(f"[DEBUG] Creating training job with spec:\n{json.dumps(job_spec, indent=2, ensure_ascii=False)}")
        path = f"{self._get_base_path()}trainingJobs"
        return self._make_request("POST", path, data=job_spec)

    def get_training_job(self, job_name: str) -> dict[str, Any]:
        """Get training job details."""
        path = f"{self._get_base_path()}trainingJobs/{job_name}"
        return self._make_request("GET", path)

    def list_training_jobs(
        self,
        filter_str: str | None = None,
        order_by: str | None = None,
        page_size: int = 20,
    ) -> dict[str, Any]:
        """List training jobs."""
        path = f"{self._get_base_path()}trainingJobs"
        params = {}
        if filter_str:
            params["filter"] = filter_str
        if order_by:
            params["orderBy"] = order_by
        if page_size:
            params["pageSize"] = page_size

        return self._make_request("GET", path, params=params)

    def stop_training_job(self, job_name: str) -> dict[str, Any]:
        """Stop a training job."""
        path = f"{self._get_base_path()}trainingJobs/{job_name}:stop"
        return self._make_request("POST", path)

    def delete_training_job(self, job_name: str) -> dict[str, Any]:
        """Delete a training job."""
        path = f"{self._get_base_path()}trainingJobs/{job_name}"
        return self._make_request("DELETE", path)

    def list_training_job_pods(self, job_name: str, page_size: int = 100) -> dict[str, Any]:
        """List pods for a training job."""
        path = f"{self._get_base_path()}trainingJobs/{job_name}/pods"
        params = {}
        if page_size:
            params["page_size"] = page_size
        return self._make_request("GET", path, params=params)

    def get_realtime_worker_log(
        self,
        job_name: str,
        pod_name: str,
        container: str | None = None,
        lines: int | None = None,
    ) -> str:
        """Get realtime logs from a worker pod."""
        # Use proxy endpoint for log API
        # Path format: /proxy/ait/data/v1/.../pods/{pod_name}/log
        path = (
            f"/proxy/ait/data/v1/subscriptions/{self.subscription}/"
            f"resourceGroups/{self.resource_group}/"
            f"regions/{self.region}/"
            f"workspaces/{self.workspace}/"
            f"trainingJobs/{job_name}/"
            f"pods/{pod_name}/log"
        )

        params = {}
        if container:
            params["container"] = container

        # Default to 1000 lines to prevent returning massive logs
        if lines is None or lines <= 0:
            lines = 1000
        params["tailLines"] = lines

        # Build full URL using compute endpoint
        url = f"{self.compute_endpoint.replace('/ait/data/v1', '')}{path}"

        # Build query string for signing (must include params in URL for auth)
        from urllib.parse import urlencode, urlparse
        if params:
            url += "?" + urlencode(params)

        # Parse URL for signing
        parsed_url = urlparse(url)
        signing_path = parsed_url.path
        if parsed_url.query:
            signing_path += "?" + parsed_url.query
        host = parsed_url.netloc

        headers = get_auth_headers(
            ak_id=self.ak_id,
            ak_secret=self.ak_secret,
            method="GET",
            path=signing_path,
            host=host,
        )

        response = requests.get(url, headers=headers, timeout=30)
        response.raise_for_status()

        return response.text

    def list_queue_nodes(
        self,
        cluster: str,
        queue: str,
        page_size: int | None = None,
        is_bound: bool = True,
    ) -> dict[str, Any]:
        """List nodes in a queue.

        Args:
            cluster: Cluster name
            queue: Queue name
            page_size: Number of nodes per page (max 100)
            is_bound: If True, return nodes bound to the queue; if False, return unbound nodes

        Returns:
            Dict containing queue nodes information
        """
        # Management API uses relative path without /compute/ssp/v1 prefix
        # because management_endpoint already includes it
        path = (
            f"/subscriptions/{self.subscription}/"
            f"resourceGroups/{self.resource_group}/"
            f"regions/{self.region}/"
            f"clusters/{cluster}/"
            f"queues/{queue}/nodes"
        )

        params = {}
        if page_size is not None:
            params["page_size"] = page_size
        if is_bound is not None:
            params["is_bound"] = "true" if is_bound else "false"

        return self._make_management_request("GET", path, params=params)

    def _make_management_request(
        self,
        method: str,
        path: str,
        data: dict[str, Any] | None = None,
        params: dict[str, Any] | None = None,
    ) -> dict[str, Any]:
        """Make authenticated request to SSP Management API."""
        from urllib.parse import urlencode, urlparse

        # Build query string
        query_string = ""
        if params:
            filtered_params = {k: v for k, v in params.items() if v is not None}
            if filtered_params:
                query_string = "?" + urlencode(filtered_params)

        # Build full URL
        url = f"{self.management_endpoint}{path}{query_string}"

        # Parse URL to extract host and path for signing
        parsed_url = urlparse(url)
        signing_path = parsed_url.path
        if parsed_url.query:
            signing_path += "?" + parsed_url.query
        host = parsed_url.netloc

        # Get authentication headers
        headers = get_auth_headers(
            ak_id=self.ak_id,
            ak_secret=self.ak_secret,
            method=method,
            path=signing_path,
            host=host,
        )

        # Make request
        response = requests.request(
            method=method,
            url=url,
            headers=headers,
            json=data,
            timeout=60,
        )
        if response.status_code >= 400:
            print(f"[API Error] {response.status_code}: {response.text}")
        response.raise_for_status()

        if response.status_code == 204:
            return {}

        return response.json() if response.text else {}

    def _make_signed_base_request(
        self,
        base_endpoint: str,
        method: str,
        path: str,
        data: dict[str, Any] | None = None,
        params: dict[str, Any] | None = None,
    ) -> dict[str, Any]:
        """Make an AKSK signed request against an arbitrary SSP base endpoint."""
        from urllib.parse import urlencode, urlparse

        query_string = ""
        if params:
            filtered_params = {k: v for k, v in params.items() if v is not None}
            if filtered_params:
                query_string = "?" + urlencode(filtered_params)

        url = f"{base_endpoint.rstrip('/')}{path}{query_string}"
        parsed_url = urlparse(url)
        signing_path = parsed_url.path
        if parsed_url.query:
            signing_path += "?" + parsed_url.query
        host = parsed_url.netloc

        headers = get_auth_headers(
            ak_id=self.ak_id,
            ak_secret=self.ak_secret,
            method=method,
            path=signing_path,
            host=host,
        )

        response = requests.request(
            method=method,
            url=url,
            headers=headers,
            json=data,
            timeout=60,
        )
        if response.status_code >= 400:
            print(f"[API Error] {response.status_code}: {response.text}")
        response.raise_for_status()

        if response.status_code == 204:
            return {}

        return response.json() if response.text else {}

    def get_workspace(self) -> dict[str, Any]:
        """Get SSP workspace metadata, including workspace uid."""
        path = (
            f"/subscriptions/{self.subscription}/"
            f"resourceGroups/{self.resource_group}/"
            f"regions/{self.region}/"
            f"workspaces/{self.workspace}"
        )
        return self._make_signed_base_request(self.management_endpoint, "GET", path)

    def list_telemetry_stations(self) -> dict[str, Any]:
        """List telemetry station resources from RMH."""
        return self._make_signed_base_request(
            self.management_base_endpoint,
            "GET",
            "/rmh/v1/resources",
            params={"filter": 'resource_type="monitor.ts.v1.telemetryStation"'},
        )

    def create_query_token(
        self,
        rid: str,
        workspace_uid: str,
        expire_time: str,
    ) -> dict[str, Any]:
        """Create a monitor query token scoped to the current workspace."""
        rid_path = rid if rid.startswith("/") else f"/{rid}"
        path = f"/monitor/ts/data/v1{rid_path}/query/token"
        data = {
            "expire_time": expire_time,
            "scope": "RESOURCE",
            "resource_type": "compute.ssp.v1.workspace",
            "resource_ids": [workspace_uid],
        }
        return self._make_signed_base_request(self.monitor_endpoint, "POST", path, data=data)

    def query_prometheus(self, query_token: str, promql: str) -> dict[str, Any]:
        """Run an instant Prometheus query using a monitor QueryToken."""
        from urllib.parse import urlencode

        url = f"{self.monitor_endpoint}/query/metrics/prometheus/api/v1/query?{urlencode({'query': promql})}"
        response = requests.get(
            url,
            headers={"Authorization": f"Bearer {query_token}"},
            timeout=60,
        )
        if response.status_code >= 400:
            print(f"[API Error] {response.status_code}: {response.text}")
        response.raise_for_status()
        return response.json() if response.text else {}


# Convenience functions for clusterx integration

def create_job(
    job_spec: dict[str, Any],
    endpoint: str,
    subscription: str,
    resource_group: str,
    region: str,
    workspace: str,
    ak_id: str,
    ak_secret: str,
) -> dict[str, Any]:
    """Create a training job."""
    client = SSPAPIClient(
        endpoint, subscription, resource_group, region, workspace, ak_id, ak_secret
    )
    return client.create_training_job(job_spec)


def get_job(
    job_name: str,
    endpoint: str,
    subscription: str,
    resource_group: str,
    region: str,
    workspace: str,
    ak_id: str,
    ak_secret: str,
) -> dict[str, Any]:
    """Get job info."""
    client = SSPAPIClient(
        endpoint, subscription, resource_group, region, workspace, ak_id, ak_secret
    )
    return client.get_training_job(job_name)


def list_jobs(
    endpoint: str,
    subscription: str,
    resource_group: str,
    region: str,
    workspace: str,
    ak_id: str,
    ak_secret: str,
    **kwargs,
) -> list[dict[str, Any]]:
    """List jobs."""
    client = SSPAPIClient(
        endpoint, subscription, resource_group, region, workspace, ak_id, ak_secret
    )
    response = client.list_training_jobs(**kwargs)
    return response.get("trainingJobs", [])


def stop_job(
    job_name: str,
    endpoint: str,
    subscription: str,
    resource_group: str,
    region: str,
    workspace: str,
    ak_id: str,
    ak_secret: str,
) -> dict[str, Any]:
    """Stop a job."""
    client = SSPAPIClient(
        endpoint, subscription, resource_group, region, workspace, ak_id, ak_secret
    )
    return client.stop_training_job(job_name)


def get_log(
    job_name: str,
    pod_name: str,
    endpoint: str,
    subscription: str,
    resource_group: str,
    region: str,
    workspace: str,
    ak_id: str,
    ak_secret: str,
    lines: int | None = None,
) -> str:
    """Get job logs."""
    client = SSPAPIClient(
        endpoint, subscription, resource_group, region, workspace, ak_id, ak_secret
    )
    return client.get_realtime_worker_log(job_name, pod_name, lines)
