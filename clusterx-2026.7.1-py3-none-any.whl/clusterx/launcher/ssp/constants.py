"""SSP launcher constants."""

SSP_CLUSTER_ENDPOINTS = {
    "D": {
        "endpoint": "https://compute.d.pjlab.org.cn",
        "management_endpoint": "https://management.d.pjlab.org.cn",
        "monitor_endpoint": "https://monitor.d.pjlab.org.cn",
    },
    "PT": {
        "endpoint": "https://compute.pjlab.org.cn",
        "management_endpoint": "https://management.pjlab.org.cn",
        "monitor_endpoint": "https://monitor.pjlab.org.cn",
    },
}
SSP_CLUSTER_TYPES = tuple(SSP_CLUSTER_ENDPOINTS)
