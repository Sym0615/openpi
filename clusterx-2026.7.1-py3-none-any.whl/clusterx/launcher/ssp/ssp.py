"""SSP Cluster implementation for clusterx."""

import json
import os
import re
import uuid
from concurrent.futures import ThreadPoolExecutor
from pathlib import Path
from typing import Annotated, Any

import requests
from cyclopts import Parameter
from pydantic import model_validator
from rich import print
from rich.console import Console
from rich.prompt import Confirm
from rich.table import Column, Table

from clusterx.config import SSPConfig
from clusterx.logger import getLogger

from ..base import (
    BaseCluster,
    BaseRunParams,
    JobSchema,
    JobStatus,
    NodeSchema,
    NodeStatus,
)
from .api import SSPAPIClient, create_job, get_job, list_jobs, stop_job
from .constants import SSP_CLUSTER_ENDPOINTS
from .prometheus_stats import (
    SSP_STATS_METRICS,
    build_cache_path,
    build_promql,
    build_scope_labels,
    get_query_token,
    merge_metric_rows,
    parse_prometheus_vector,
    resolve_metric_keys,
)
from .ssp_info import SSPPartition

logger = getLogger("clusterx.launcher.ssp")

# Status mapping from SSP to clusterx
STATUS_MAPPING = {
    "PENDING": JobStatus.QUEUING,
    "RUNNING": JobStatus.RUNNING,
    "RESTARTING": JobStatus.QUEUING,
    "COMPLETING": JobStatus.SUCCEEDED,
    "COMPLETED": JobStatus.SUCCEEDED,
    "TERMINATING": JobStatus.STOPPED,
    "TERMINATED": JobStatus.STOPPED,
    "FAILED": JobStatus.FAILED,
}

# Framework to role mapping
FRAMEWORK_ROLES = {
    "PYTORCH_DDP": ("PYTORCH_MASTER", "PYTORCH_WORKER"),
    "MPI": ("MPI_MASTER", "MPI_WORKER"),
    "RAY_JOB": ("RAY_HEAD", "RAY_WORKER"),
    "TENSORFLOW_PS": ("CHIEF", "WORKER"),
    "FRAMEWORK_CUSTOM": ("MASTER", "WORKER"),
}


@Parameter(name="*")
class SSPRunParams(BaseRunParams[str]):
    """SSP task run parameters."""

    # Override base params (hidden - use queue instead)
    partition: Annotated[
        str | None, Parameter(help="分区名", show=False)
    ] = None

    # Queue name (replaces partition for SSP, supports both -p and -q)
    queue: Annotated[
        str | None, Parameter(help="队列名", name=["-q", "--queue", "-p", "--partition"])
    ] = None

    cluster: Annotated[
        str | None, Parameter(help="集群名，优先级高于配置文件中的 cluster", name=["-C", "--cluster-name"])
    ] = None

    # Machine type for node affinity (e.g., x2ls.ri.i80)
    machine_type: Annotated[
        str | None, Parameter(help="机型规格，例如: x2ls.ri.i80")
    ] = None

    priority: Annotated[
        int, Parameter(help="优先级 (1=NORMAL, 2=HIGH, 3=HIGHEST)")
    ] = 1

    tasks_per_node: Annotated[
        int, Parameter(help="每个任务使用的节点数", show=False)
    ] = 1

    # Node selection with host names
    include: Annotated[
        str | None, Parameter(help="指定机器hostname列表，逗号分隔，如: host-10-12-139-14,host-10-12-139-15")
    ] = None

    exclude: Annotated[
        str | None, Parameter(help="排除机器hostname列表，逗号分隔，如: host-10-12-138-107,host-10-12-138-108")
    ] = None

    # Retry with max attempts (number of retries, default None for no retry)
    retry: Annotated[
        int | None, Parameter(help="最大重试次数，默认不重试")
    ] = None

    no_env: Annotated[
        bool,
        Parameter(
            help=(
                "不继承当前 shell 环境变量；未设置时会导出当前环境。"
                "-e KEY=VALUE 仍会写入 SSP job spec。"
            ),
            negative=False,
        ),
    ] = False

    environment: Annotated[
        list[str] | None,
        Parameter(
            help=(
                "设置 SSP job spec 环境变量，格式 KEY=VALUE；多个变量需重复使用，"
                "例如 -e A=1 -e B=2。"
            ),
            name=["environment", "-e"],
            negative=False,
        ),
    ] = None

    preemptible: Annotated[
        bool | None, Parameter(help="SSP 不支持作业级别的抢占式任务（请改在队列级别配置）。", show=False)
    ] = None

    enable_privileged: Annotated[
        bool, Parameter(help="是否开启特权模式，开启后将获得宿主机的 root 权限", negative=False)
    ] = False

    @model_validator(mode="before")
    def convert_input(cls, data):
        """Override base validator to handle string queue."""
        # Queue is already a string, no conversion needed
        return data

    # SSP-specific parameters
    image: Annotated[
        str | None, Parameter(help="容器镜像地址 URL")
    ] = None

    # Tensorboard configuration (hidden - use API directly if needed)
    tensorboard_log_path: Annotated[
        str | None, Parameter(help="Tensorboard 日志路径", show=False)
    ] = None
    tensorboard_port: Annotated[
        int, Parameter(help="Tensorboard 端口", show=False)
    ] = 6006

    # Volume mounts
    mount: Annotated[
        list[str] | None,
        Parameter(
            help="卷挂载, 格式: type:id:mount_path[:subdir] 或 JSON 对象 "
                 "(如 {\"type\":\"PV_AOSS\",\"endpoint\":\"...\",\"mount_path\":\"...\","
                 "\"name\":\"...\",\"metadata\":{\"items\":[...]}}); "
                 "可重复使用 --mount 指定多个挂载, 也可在单个 --mount 中用逗号分隔"
        ),
    ] = None

    # Network and resources (hidden - use config file instead)
    rdma_name: Annotated[
        str | None, Parameter(help="RDMA 网络名称", show=False)
    ] = None
    shm_size_gib: Annotated[
        int, Parameter(help="共享内存大小（单位：GiB），不超过 memory-per-task")
    ] = 64

    # Fault tolerance (hidden - use config file instead)
    fault_tolerance_max_attempts: Annotated[
        int | None, Parameter(help="容错最大重试次数", show=False)
    ] = None

    # Storage credentials 
    storage_ak_id: Annotated[
        str | None, Parameter(help="存储卷 access_key ID")
    ] = None
    storage_ak_secret: Annotated[
        str | None, Parameter(help="存储卷 access_key secret")
    ] = None

    # Temporary directory (hidden - use config file)
    tmpdir: Annotated[
        str | None, Parameter(help="worker 节点可访问的临时目录", show=False)
    ] = None


class SSPCluster(BaseCluster[SSPRunParams, SSPPartition]):
    """SSP (SenseCore Platform) cluster launcher."""

    def __init__(self):
        from clusterx import CLUSTERX_CONFIG

        super().__init__()

        if CLUSTERX_CONFIG.ssp is None:
            raise ValueError("SSP configuration not found. Please run 'clusterx config' first.")

        self.cfg = CLUSTERX_CONFIG.ssp
        self._validate_config()

        cluster_type = self.cfg.get("cluster_type", "PT").upper()
        if cluster_type not in SSP_CLUSTER_ENDPOINTS:
            valid_types = ", ".join(SSP_CLUSTER_ENDPOINTS)
            raise ValueError(f"Invalid SSP cluster type: {cluster_type}. Valid values: {valid_types}")

        default_endpoints = SSP_CLUSTER_ENDPOINTS[cluster_type]
        endpoint = self.cfg.get("endpoint", default_endpoints["endpoint"])
        management_endpoint = self.cfg.get("management_endpoint", default_endpoints["management_endpoint"])
        monitor_endpoint = self.cfg.get("monitor_endpoint", default_endpoints["monitor_endpoint"])

        # Initialize API client
        self.client = SSPAPIClient(
            compute_endpoint=endpoint,
            management_endpoint=management_endpoint,
            monitor_endpoint=monitor_endpoint,
            subscription=self.cfg["subscription"],
            resource_group=self.cfg["resource_group"],
            region=self.cfg["region"],
            workspace=self.cfg["workspace"],
            ak_id=self.cfg["ak_id"],
            ak_secret=self.cfg["ak_secret"],
        )

    def _validate_config(self) -> None:
        """Validate SSP configuration."""
        required_fields = [
            "subscription",
            "resource_group",
            "region",
            "workspace",
            "cluster",
            "ak_id",
            "ak_secret",
        ]

        for field in required_fields:
            if field not in self.cfg or not self.cfg[field]:
                raise ValueError(f"SSP configuration missing required field: {field}")

    def run(self, run_params: SSPRunParams) -> JobSchema:
        """Submit a training job to SSP."""
        # Build command
        cmd = self._build_command(run_params.cmd, run_params.no_env)

        # Get temp directory
        tmpdir = self._get_tmpdir(run_params)

        # Write command to script file
        cmd_name = uuid.uuid4()
        cmd_path = tmpdir / f"{cmd_name}.sh"
        cmd_path.parent.mkdir(parents=True, exist_ok=True)
        with open(cmd_path, "w") as f:
            f.write(cmd)

        # Update command to run the script
        cmd = f"bash {cmd_path}"

        # Get image
        image = run_params.image or self.cfg.get("image")
        if not image:
            raise ValueError("Container image must be specified via --image or config")

        # Parse volume mounts (config + command line)
        config_mounts = self.cfg.get("mount", "")

        # Parse config mounts
        if isinstance(config_mounts, list):
            # Structured list from config (supports PV_AOSS etc.)
            config_volume_mounts = []
            for m in config_mounts:
                mount = dict(m)
                if isinstance(mount.get("type"), str):
                    mount["type"] = mount["type"].upper()
                config_volume_mounts.append(mount)
        else:
            # String format from config
            config_volume_mounts = self._parse_volume_mounts(config_mounts) if config_mounts else []

        # Parse CLI mounts (list[str] -> join with comma -> parse)
        cli_mounts_str = ",".join(run_params.mount) if run_params.mount else ""
        cli_volume_mounts = self._parse_volume_mounts(cli_mounts_str)

        volume_mounts = config_volume_mounts + cli_volume_mounts

        # Get storage credentials
        storage_ak_id = run_params.storage_ak_id or self.cfg.get("storage_ak_id")
        storage_ak_secret = run_params.storage_ak_secret or self.cfg.get("storage_ak_secret")

        # Build job spec
        job_spec = self._build_job_spec(run_params, cmd, image, volume_mounts, storage_ak_id, storage_ak_secret)

        # Create job
        try:
            response = self.client.create_training_job(job_spec)
            job_name = response.get("name")

            if not job_name:
                raise RuntimeError(f"Failed to create job: {response}")

            # Get job info
            job_info = self.client.get_training_job(job_name)
            job_schema = self._convert_to_job_schema(job_info)

            logger.info(f"Job {job_name} created successfully")

            return job_schema

        except Exception as e:
            logger.exception("Failed to submit job to SSP")
            raise

    def _build_job_spec(
        self,
        run_params: SSPRunParams,
        cmd: str,
        image: str,
        volume_mounts: list[dict],
        storage_ak_id: str | None,
        storage_ak_secret: str | None,
    ) -> dict[str, Any]:
        """Build SSP job specification."""
        # Get queue ID from queue parameter (command line or config)
        queue = run_params.queue or self.cfg.get("queue") or self.cfg.get("partition")
        queue_id = self._get_queue_id(queue, cluster=run_params.cluster)

        # Build metadata with storage credentials if needed
        metadata_items = []
        if run_params.enable_privileged:
            metadata_items.append({"key": "enable-privileged", "value": "true"})
        else:
            metadata_items.append({"key": "enable-privileged", "value": "false"})
        if storage_ak_id and storage_ak_secret and volume_mounts:
            metadata_items.extend([
                {"key": "access-key", "value": storage_ak_id},
                {"key": "secret-key", "value": storage_ak_secret},
            ])

        # Map priority
        priority = self._map_priority(run_params.priority)

        # Build tasks
        tasks = self._build_tasks(run_params, cmd, image)

        # Build tensorboard config
        tensorboard = None
        if run_params.tensorboard_log_path:
            tensorboard = {
                "log_path": run_params.tensorboard_log_path,
                "port": run_params.tensorboard_port,
            }

        # Build fault tolerance
        fault_tolerance = None
        if run_params.retry is not None and run_params.retry > 0:
            fault_tolerance = {"max_attempts": run_params.retry}
        elif run_params.fault_tolerance_max_attempts:
            fault_tolerance = {"max_attempts": run_params.fault_tolerance_max_attempts}

        # Parse environment variables
        envs = {}
        if run_params.environment:
            for env_str in run_params.environment:
                if "=" in env_str:
                    key, value = env_str.split("=", 1)
                    envs[key] = value

        job_spec: dict[str, Any] = {
            "name": run_params.job_name,
            "display_name": run_params.job_name,
            "spec": {
                "queue": {"id": queue_id},
                "framework": "PYTORCH_DDP",
                "vc_job": {
                    "tasks": tasks,
                },
            },
        }

        # Add optional fields only if they have values
        if metadata_items:
            job_spec["metadata"] = {"items": metadata_items}
        if priority:
            job_spec["spec"]["priority"] = priority
        if envs:
            job_spec["spec"]["envs"] = envs
        if volume_mounts:
            job_spec["spec"]["volume_mounts"] = volume_mounts
        if tensorboard:
            job_spec["spec"]["tensorboard"] = tensorboard
        if fault_tolerance:
            job_spec["spec"]["vc_job"]["fault_tolerance"] = fault_tolerance

        return job_spec

    def _build_tasks(self, run_params: SSPRunParams, cmd: str, image: str) -> list[dict]:
        """Build task specifications."""
        num_nodes = run_params.num_nodes

        # Get role based on framework and node count (fixed to PYTORCH_DDP)
        master_role, worker_role = FRAMEWORK_ROLES.get(
            "PYTORCH_DDP", ("MASTER", "WORKER")
        )

        # Build resource spec
        # SSP API requires 0 <= shm_size_gib < memory_gib
        if run_params.shm_size_gib >= run_params.memory_per_task:
            shm_size_gib = run_params.memory_per_task - 1
            logger.warning(
                f"shm_size_gib ({run_params.shm_size_gib}) must be less than memory_per_task "
                f"({run_params.memory_per_task}), clamped to {shm_size_gib}"
            )
        else:
            shm_size_gib = run_params.shm_size_gib
        resource_spec: dict[str, Any] = {
            "cpu_count": run_params.cpus_per_task,
            "memory_gib": run_params.memory_per_task,
            "accelerate_device_count": run_params.gpus_per_task,
            "shm_size_gib": shm_size_gib,
        }

        # Add machine_type to resource_spec if specified
        machine_type = run_params.machine_type or self.cfg.get("machine_type")
        if machine_type:
            resource_spec["machine_types"] = [machine_type]

        # RDMA is required by SSP API when using GPUs
        rdma_name = run_params.rdma_name or self.cfg.get("rdma_name")
        if run_params.gpus_per_task > 0 and not rdma_name:
            raise ValueError(
                "RDMA network name is required for GPU tasks. "
                "Please set it via --rdma-name or config 'rdma_name'"
            )
        if rdma_name:
            resource_spec["rdma_name"] = rdma_name

        # Build scheduling affinity with node affinity
        scheduling = {}
        match_expressions = []

        # Add machine type affinity
        if machine_type:
            match_expressions.append({
                "key": "resource.compute.sensecore.cn/machine-type",
                "operator": "IN",
                "values": [machine_type]
            })

        # Add include hosts affinity
        if run_params.include:
            match_expressions.append({
                "key": "kubernetes.io/hostname",
                "operator": "IN",
                "values": run_params.include.split(",")
            })

        # Add exclude hosts affinity
        if run_params.exclude:
            match_expressions.append({
                "key": "kubernetes.io/hostname",
                "operator": "NOT_IN",
                "values": run_params.exclude.split(",")
            })

        if match_expressions:
            scheduling = {
                "affinity": {
                    "node_affinity": {
                        "required_during_scheduling_ignored_during_execution": {
                            "node_selector_terms": [
                                {
                                    "match_expressions": match_expressions
                                }
                            ]
                        }
                    }
                }
            }

        if num_nodes == 1:
            # Single node: SSP requires PYTORCH_WORKER role for single-node jobs
            task: dict[str, Any] = {
                "name": "task",
                "role": worker_role,
                "replicas": 1,
                "image": image,
                "command": ["bash", "-c"],
                "args": [cmd],
                "resource_spec": resource_spec,
            }
            if scheduling:
                task["scheduling"] = scheduling
            return [task]
        else:
            # Multi-node: separate master and worker tasks
            master_task: dict[str, Any] = {
                "name": "master",
                "role": master_role,
                "replicas": 1,
                "image": image,
                "command": ["bash", "-c"],
                "args": [cmd],
                "resource_spec": resource_spec,
            }
            if scheduling:
                master_task["scheduling"] = scheduling

            worker_task: dict[str, Any] = {
                "name": "worker",
                "role": worker_role,
                "replicas": num_nodes - 1,
                "image": image,
                "command": ["bash", "-c"],
                "args": [cmd],
                "resource_spec": resource_spec,
            }
            if scheduling:
                worker_task["scheduling"] = scheduling

            return [master_task, worker_task]

    @staticmethod
    def _split_volume_mount_string(mounts_str: str) -> list[str]:
        """Split volume mounts by commas, respecting JSON object/array/string boundaries."""
        result, current, depth, in_string, escape = [], [], 0, False, False
        for char in mounts_str:
            if escape:
                current.append(char); escape = False; continue
            if char == '\\':
                current.append(char); escape = True; continue
            if char == '"':
                in_string = not in_string; current.append(char); continue
            if in_string:
                current.append(char); continue
            if char in '{[':
                depth += 1; current.append(char)
            elif char in '}]':
                depth -= 1; current.append(char)
            elif char == ',' and depth == 0:
                result.append(''.join(current).strip()); current = []
            else:
                current.append(char)
        if current:
            result.append(''.join(current).strip())
        return [s for s in result if s]

    def _parse_volume_mounts(self, volume_mounts_str: str | None) -> list[dict]:
        """Parse volume mounts string into list of mount specs."""
        if not volume_mounts_str:
            return []

        mounts = []
        for mount_str in self._split_volume_mount_string(volume_mounts_str):
            mount_str = mount_str.strip()
            if not mount_str:
                continue

            if mount_str.startswith("{"):
                try:
                    mount = json.loads(mount_str)
                except json.JSONDecodeError as e:
                    logger.warning(f"Invalid JSON volume mount: {mount_str}: {e}")
                    continue
                if not isinstance(mount, dict):
                    logger.warning(f"JSON volume mount is not an object: {mount_str}")
                    continue
                if isinstance(mount.get("type"), str):
                    mount["type"] = mount["type"].upper()
                mounts.append(mount)
                continue

            parts = mount_str.split(":")
            if len(parts) < 3:
                logger.warning(f"Invalid volume mount format: {mount_str}")
                continue

            mount = {
                "type": parts[0].upper(),
                "id": parts[1],
                "mount_path": parts[2],
            }

            if len(parts) >= 4:
                mount["subdir"] = parts[3]

            mounts.append(mount)

        return mounts

    def _get_queue_id(self, partition: SSPPartition | str | None, *, cluster: str | None = None) -> str:
        """Get queue ID from partition."""
        if partition is None:
            raise ValueError(
                "Partition (queue) must be specified. "
                "Please set it via --partition/-p or config 'partition'"
            )

        if isinstance(partition, SSPPartition):
            partition_name = partition.value
        else:
            partition_name = partition

        # Build full queue ID path with region and cluster
        subscription = self.cfg['subscription']
        resource_group = self.cfg['resource_group']
        region = self.cfg['region']

        # Get cluster name from CLI override or config
        cluster = cluster or self.cfg.get('cluster')
        if not cluster:
            raise ValueError(
                "Cluster name must be specified. "
                "Please set it in config 'cluster' or pass --cluster-name/-C"
            )

        return f"/subscriptions/{subscription}/resourceGroups/{resource_group}/regions/{region}/clusters/{cluster}/queues/{partition_name}"

    def _map_priority(self, priority: int) -> str:
        """Map clusterx priority to SSP priority."""
        if priority >= 3:
            return "HIGHEST"
        elif priority >= 2:
            return "HIGH"
        else:
            return "NORMAL"

    def _get_tmpdir(self, run_params: SSPRunParams) -> Path:
        """Get temporary directory."""
        if run_params.tmpdir:
            return Path(run_params.tmpdir)

        tmpdir = self.cfg.get("tmpdir")
        if not tmpdir:
            return Path.home() / ".tmp"

        return Path(tmpdir)

    def _build_command(self, cmd: str, no_env: bool) -> str:
        """Build command with environment setup."""
        # Add PyTorch DDP environment variables for distributed training
        _cmd = self._build_pytorch_ddp_cmd()

        if not no_env:
            env_cmd = ""
            inherited_env = {k: v for k, v in os.environ.items() if v}
            for k, v in inherited_env.items():
                env_cmd += f"export {k}='{v}'\n"
            _cmd += env_cmd
            _cmd += f"cd {os.getcwd()}\n"

        return _cmd + cmd

    def _build_pytorch_ddp_cmd(self) -> str:
        """Build PyTorch DDP environment setup command."""
        return (
            "export MASTER_ADDR=${MASTER_ADDR:-$HOSTNAME}\n"
            "export MASTER_PORT=${MASTER_PORT:-6000}\n"
            "export WORLD_SIZE=${WORLD_SIZE:-$NODE_COUNT}\n"
            "export RANK=${RANK:-$NODE_RANK}\n"
        )

    def _convert_to_job_schema(self, job_info: dict[str, Any]) -> JobSchema:
        """Convert SSP job info to clusterx JobSchema."""
        spec = job_info.get("spec", {})
        vc_job = spec.get("vc_job", {})
        tasks = vc_job.get("tasks", [])
        metadata = job_info.get("metadata", {})
        ownership = job_info.get("ownership", {})
        status = job_info.get("status", {})

        # Get first task info
        task = tasks[0] if tasks else {}
        resource_spec = task.get("resource_spec", {})

        # Get nodes from status
        nodes = []
        nodes_ip = []
        task_statuses = status.get("tasks", [])
        for task_status in task_statuses:
            resources = task_status.get("resources", [])
            for res in resources:
                if res.get("node_name"):
                    nodes.append(res["node_name"])
                if res.get("ip"):
                    nodes_ip.append(res["ip"])

        # Parse queue to get partition
        queue_id = spec.get("queue", {}).get("id", "")
        partition = queue_id.split("/")[-1] if queue_id else "unknown"

        # Calculate total nodes across all tasks
        total_nodes = sum(t.get("replicas", 0) for t in tasks) if tasks else 0

        return JobSchema(
            job_id=job_info.get("name", ""),
            job_name=job_info.get("display_name"),
            user=ownership.get("creator_name", ""),
            gpus_per_node=resource_spec.get("accelerate_device_count", 0),
            cpus_per_node=resource_spec.get("cpu_count", 0),
            memory=f"{resource_spec.get('memory_gib', 0)}Gi",
            status=self._map_status(status.get("state", "")),
            num_nodes=total_nodes,
            partition=partition,
            nodes=nodes if nodes else None,
            nodes_ip=nodes_ip if nodes_ip else None,
            start_time=metadata.get("created_at"),
            end_time=status.get("terminated_at"),
            cmd=" ".join(task.get("command", []) + task.get("args", [])),
        )

    def _map_status(self, status: str) -> JobStatus:
        """Map SSP status to clusterx JobStatus."""
        return STATUS_MAPPING.get(status.upper(), JobStatus.UNRECORGNIZED)

    def _map_filter_status(self, status: JobStatus) -> str | None:
        """Map clusterx JobStatus to SSP state string for filtering."""
        reverse_mapping = {
            JobStatus.QUEUING: "PENDING",
            JobStatus.RUNNING: "RUNNING",
            JobStatus.SUCCEEDED: "COMPLETED",
            JobStatus.STOPPED: "TERMINATED",
            JobStatus.FAILED: "FAILED",
        }
        return reverse_mapping.get(status)

    def stop(
        self,
        *,
        job_id: str | None = None,
        regex: str | None = None,
        group: str | None = None,
        user: str | None = None,
        partition: SSPPartition | None = None,
        status: JobStatus | None = None,
        confirm: bool = False,
    ) -> None:
        """Stop training job(s)."""
        if group is not None:
            raise NotImplementedError("Stopping by group is not supported for SSP")

        if job_id is not None:
            # Stop single job
            try:
                self.client.stop_training_job(job_id)
                logger.info(f"Job {job_id} stopped")
            except Exception as e:
                logger.error(f"Failed to stop job {job_id}: {e}")
                raise
        else:
            # Stop multiple jobs based on filters
            jobs = self._list_jobs_with_filters(user, partition, status, regex)

            if not jobs:
                logger.info("No matching jobs found")
                return

            if confirm:
                console = Console()
                confirm_check = Confirm("Stop the following jobs?", console=console)

                table = Table(
                    Column("Job Name", min_width=40, max_width=80),
                    Column("Job ID", max_width=30),
                    Column("Status", max_width=20),
                )
                for job in jobs:
                    table.add_row(
                        job.get("display_name", ""),
                        job.get("name", ""),
                        job.get("status", {}).get("state", ""),
                    )
                console.print(table)

                if not confirm_check.ask():
                    return

            # Stop jobs in parallel
            job_ids = [job["name"] for job in jobs]
            with ThreadPoolExecutor(max_workers=16) as pool:
                list(pool.map(self.client.stop_training_job, job_ids))

            logger.info(f"Stopped {len(job_ids)} jobs")

    def delete_jobs(
        self,
        job_id: str | None = None,
        *,
        regex: str | None = None,
        group: str | None = None,
        user: str | None = None,
        partition: SSPPartition | None = None,
        status: JobStatus | None = None,
        confirm: bool = False,
    ) -> None:
        """Delete jobs by ID, regex, or filters.

        Args:
            job_id: Specific job ID to delete
            regex: Regex pattern to match job names
            group: Group/namespace filter
            user: User filter
            partition: Partition/queue filter
            status: Job status filter
            confirm: Whether to show confirmation prompt
        """
        # Handle single job deletion
        if job_id and not regex:
            try:
                self.client.delete_training_job(job_id)
                logger.info(f"Job {job_id} deleted")
                return
            except Exception as e:
                logger.error(f"Failed to delete job {job_id}: {e}")
                return

        # Filter-based deletion
        with self.handle_api_errors("delete jobs"):
            jobs = self._list_jobs_with_filters(user, partition, status, regex)

            if not jobs:
                logger.info("No matching jobs found")
                return

            if confirm:
                console = Console()
                confirm_check = Confirm("Delete the following jobs?", console=console)

                table = Table(
                    Column("Job Name", min_width=40, max_width=80),
                    Column("Job ID", max_width=30),
                    Column("Status", max_width=20),
                )
                for job in jobs:
                    table.add_row(
                        job.get("display_name", ""),
                        job.get("name", ""),
                        job.get("status", {}).get("state", ""),
                    )
                console.print(table)

                if not confirm_check.ask():
                    return

            # Delete jobs in parallel
            job_ids = [job["name"] for job in jobs]
            with ThreadPoolExecutor(max_workers=16) as pool:
                list(pool.map(self.client.delete_training_job, job_ids))

            logger.info(f"Deleted {len(job_ids)} jobs")

    def delete_jobs_cli(
        self,
        job_id: Annotated[str | None, Parameter(name=["--job-id", "-j"])] = None,
        *,
        regex: Annotated[str | None, Parameter(help="正则表达式，用于过滤 job 任务名称")] = None,
        group: Annotated[str | None, Parameter(name=["--group", "-g"])] = None,
        user: Annotated[str | None, Parameter(name=["--user", "-u"])] = None,
        partition: Annotated[SSPPartition | None, Parameter(name=["-p", "--partition"])] = None,
        status: Annotated[JobStatus | None, Parameter(name=["--status", "-s"])] = None,
        confirm: Annotated[bool, Parameter(name=["--confirm", "-c"])] = False,
    ) -> None:
        """CLI entry point for deleting jobs.

        Examples:
          clusterx del my-job-id           # Delete specific job
          clusterx del -j my-job-id        # Same as above
          clusterx del --regex test.*      # Delete all matching jobs
        """
        self.delete_jobs(
            job_id=job_id,
            regex=regex,
            group=group,
            user=user,
            partition=partition,
            status=status,
            confirm=confirm,
        )

    def _list_jobs_with_filters(
        self,
        user: str | None,
        partition: str | None,
        status: JobStatus | None,
        regex: str | None,
        workspace: str | None = None,
    ) -> list[dict]:
        """List jobs with filters applied."""
        # Build filter string for SSP API
        # Format: creator_name="xxx" AND (state="RUNNING")
        filters = []

        if user:
            filters.append(f'creator_name="{user}"')

        if partition:
            queue_id = self._get_queue_id(partition)
            filters.append(f'queue_id="{queue_id}"')

        if status:
            # Map clusterx status to SSP state
            ssp_state = self._map_filter_status(status)
            if ssp_state:
                filters.append(f'state="{ssp_state}"')

        filter_str = " AND ".join(filters) if filters else None

        # Get jobs from API
        response = self.client.list_training_jobs(filter_str=filter_str, page_size=1000)
        jobs = response.get("training_jobs") or response.get("trainingJobs", [])

        # Apply additional filters (status, regex)
        filtered_jobs = []
        for job in jobs:
            job_status = self._map_status(job.get("status", {}).get("state", ""))

            if status is not None and job_status != status:
                continue

            if regex is not None:
                job_name = job.get("display_name", "")
                if not re.search(regex, job_name):
                    continue

            filtered_jobs.append(job)

        return filtered_jobs

    def list_jobs(
        self,
        *,
        group: str | None = None,
        user: str | None = None,
        partition: str | None = None,
        status: JobStatus | None = None,
        regex: str | None = None,
        num: int = 20,
        out: Path | None = None,
        verbose: bool = False,
        workspace: str | None = None,
    ) -> list[JobSchema]:
        """List training jobs."""
        if group is not None:
            raise NotImplementedError("Listing by group is not supported for SSP")

        jobs = self._list_jobs_with_filters(user, partition, status, regex, workspace)

        # Convert to JobSchema
        job_schemas = []
        for job in jobs[:num]:
            try:
                job_schema = self._convert_to_job_schema(job)
                job_schemas.append(job_schema)
            except Exception as e:
                logger.warning(f"Failed to parse job {job.get('name')}: {e}")

        if verbose:
            console = Console()
            table = Table(
                Column("Job Name", min_width=40, max_width=80),
                Column("Job ID", max_width=30),
                Column("Status", max_width=15),
                Column("GPU", max_width=10),
                Column("CPU", max_width=10),
                Column("Memory", max_width=15),
                Column("Nodes", max_width=10),
            )
            for schema in job_schemas:
                table.add_row(
                    schema.job_name or "",
                    str(schema.job_id),
                    str(schema.status),
                    str(schema.gpus_per_node),
                    str(schema.cpus_per_node),
                    schema.memory,
                    str(schema.num_nodes),
                )
            console.print(table)

        if out is not None:
            out.parent.mkdir(exist_ok=True, parents=True)
            with out.open("w") as f:
                json.dump([j.model_dump() for j in job_schemas], f, indent=4)

        return job_schemas

    def get_job_info(self, /, job_id: str, verbose=False) -> JobSchema:
        """Get job information."""
        try:
            job_info = self.client.get_training_job(job_id)
            job_schema = self._convert_to_job_schema(job_info)
            return job_schema

        except Exception as e:
            logger.error(f"Failed to get job info for {job_id}: {e}")
            raise

    def get_log(self, job_id: str, lines: int | None = None) -> str:
        """Get job logs using the list pods API."""
        try:
            # Get pods for the training job
            pods_response = self.client.list_training_job_pods(job_id)
            pods = pods_response.get("training_job_pods", [])

            if not pods:
                return "No pods found for job"

            logs = []
            for item in pods:
                pod = item.get("pod", {})
                pod_meta = pod.get("metadata", {})
                pod_name = pod_meta.get("name")
                if pod_name:
                    try:
                        pod_log = self.client.get_realtime_worker_log(
                            job_id, pod_name, lines=lines
                        )
                        logs.append(f"=== Pod: {pod_name} ===\n{pod_log}")
                    except Exception as e:
                        logger.warning(f"Failed to get log for pod {pod_name}: {e}")

            return "\n\n".join(logs) if logs else "No logs available"

        except Exception as e:
            logger.error(f"Failed to get logs for job {job_id}: {e}")
            return f"Error retrieving logs: {e}"

    def stats_node(
        self,
        /,
        queue: str | None = None,
        *,
        cluster: str | None = None,
        out: Path | None = None,
        verbose=False,
    ) -> list[NodeSchema]:
        """Get node statistics for a queue.

        Args:
            queue: Queue name (e.g., 'default', 'gpu')
            out: Optional output file path to save results
            verbose: Whether to print verbose output

        Returns:
            List of NodeSchema with node information
        """
        queue = queue or self.cfg.get("queue") or self.cfg.get("partition")
        if not queue:
            raise ValueError("Queue must be specified via --queue/-q or config 'queue'")

        # Get cluster from config
        cluster = cluster or self.cfg.get('cluster')
        if not cluster:
            raise ValueError("Cluster name must be specified in config 'cluster' or pass --cluster-name/-C")

        # Call API to get queue nodes
        response = self.client.list_queue_nodes(cluster=cluster, queue=queue)
        nodes = response.get("nodes", [])

        # Use verbose schema to include allocated resources
        class NodeSchemaVerbose(NodeSchema):
            allocated_gpu: int = 0
            allocated_cpu: int = 0
            allocated_memory: str = "0"

        nodes_schema: list[NodeSchemaVerbose] = []
        for node in nodes:
            # Node fields are at the top level (not nested in properties)
            summary_data = node.get("summary_data", [])

            # Parse summary_data to get resource info
            total_gpu = 0
            total_cpu = 0
            total_memory = "0"
            allocated_gpu = 0
            allocated_cpu = 0
            allocated_memory = "0"

            for resource in summary_data:
                resource_type = resource.get("resource_type", "").upper()
                if resource_type == "DEVICE":
                    total_gpu = int(resource.get("total", 0))
                    allocated_gpu = int(resource.get("allocated", 0))
                elif resource_type == "CPU":
                    total_cpu = int(resource.get("total", 0))
                    allocated_cpu = int(resource.get("allocated", 0))
                elif resource_type == "MEMORY":
                    # Check unit - if GiB, use value directly; otherwise assume bytes
                    unit = resource.get("unit", "")
                    if unit == "GiB":
                        total_memory = str(int(resource.get("total", 0)))
                        allocated_memory = str(int(resource.get("allocated", 0)))
                    else:
                        # Value is in bytes, convert to GB
                        memory_bytes = int(resource.get("total", 0))
                        total_memory = str(memory_bytes // (1024 * 1024 * 1024))
                        allocated_bytes = int(resource.get("allocated", 0))
                        allocated_memory = str(allocated_bytes // (1024 * 1024 * 1024))

            # Determine node status based on state and resource allocation
            state = node.get("state", "Unknown")
            node_status = self._determine_node_status(
                state, allocated_gpu, allocated_cpu, allocated_memory
            )

            node_schema = NodeSchemaVerbose(
                name=node.get("name", "Unknown"),
                total_gpu=total_gpu,
                total_cpu=total_cpu,
                total_memory=total_memory,
                status=node_status,
                allocated_gpu=allocated_gpu,
                allocated_cpu=allocated_cpu,
                allocated_memory=allocated_memory,
            )
            nodes_schema.append(node_schema)

        if verbose:
            console = Console()
            table = Table(
                Column(header="节点名", max_width=35),
                Column(header="状态", max_width=10),
                Column(header="GPU(已用/总量)", max_width=15),
                Column(header="CPU(已用/总量)", max_width=15),
                Column(header="内存GB(已用/总量)", max_width=18),
            )

            for node in nodes_schema:
                table.add_row(
                    node.name,
                    str(node.status),
                    f"{node.allocated_gpu}/{node.total_gpu}",
                    f"{node.allocated_cpu}/{node.total_cpu}",
                    f"{node.allocated_memory}/{node.total_memory}",
                )

            console.print(table)

            # Print summary
            summarize = Table(
                Column(header="总节点数", max_width=12),
                Column(header="正常节点数", max_width=12),
                Column(header="坏节点数", max_width=12),
                Column(header="空闲节点数", max_width=12),
            )
            total = len(nodes_schema)
            ready = sum(1 for n in nodes_schema if n.status != NodeStatus.DRAIN)
            unhealthy = sum(1 for n in nodes_schema if n.status == NodeStatus.DRAIN)
            idle = sum(1 for n in nodes_schema if n.status == NodeStatus.IDLE)
            summarize.add_row(str(total), str(ready), str(unhealthy), str(idle))
            console.print(summarize)

        if out is not None:
            out.parent.mkdir(exist_ok=True, parents=True)
            with out.open("w") as f:
                json.dump([n.model_dump() for n in nodes_schema], f, indent=4)

        return nodes_schema

    def stats_prometheus(
        self,
        *,
        scope: str = "queue",
        metric: str = "all",
        minutes: int = 5,
        step: int = 30,
        cluster: str | None = None,
        queue: str | None = None,
        job: str | None = None,
        out: Path | None = None,
        verbose: bool = True,
    ) -> list[dict[str, Any]]:
        """Query SSP Prometheus metrics and return rows grouped by Hostname."""
        _ = step
        cluster = cluster or self.cfg.get("cluster")
        queue = queue or self.cfg.get("queue") or self.cfg.get("partition")
        metric_keys = resolve_metric_keys(metric)
        labels = build_scope_labels(
            scope=scope,
            workspace=self.cfg["workspace"],
            cluster=cluster,
            queue=queue,
            job=job,
        )

        cache_path = build_cache_path(
            self.cfg["subscription"],
            self.cfg["resource_group"],
            self.cfg["region"],
            self.cfg["workspace"],
        )
        token_info = get_query_token(self.client, cache_path=cache_path)

        metric_values: dict[str, dict[str, float]] = {}
        for metric_key in metric_keys:
            promql = build_promql(metric_key, labels, minutes)
            try:
                response = self.client.query_prometheus(token_info["query_token"], promql)
            except requests.HTTPError as e:
                status_code = e.response.status_code if e.response is not None else None
                if status_code not in (401, 403):
                    raise
                cache_path.unlink(missing_ok=True)
                token_info = get_query_token(self.client, cache_path=cache_path)
                response = self.client.query_prometheus(token_info["query_token"], promql)
            metric_values[metric_key] = parse_prometheus_vector(response)

        rows = merge_metric_rows(metric_values)
        for row in rows:
            row["scope"] = scope
            row["window"] = f"{minutes}m"

        if verbose:
            self._print_prometheus_stats(rows, metric_keys, scope=scope, minutes=minutes)

        if out is not None:
            out.parent.mkdir(exist_ok=True, parents=True)
            with out.open("w") as f:
                json.dump(rows, f, indent=4)

        return rows

    def _print_prometheus_stats(
        self,
        rows: list[dict[str, Any]],
        metric_keys: list[str],
        *,
        scope: str,
        minutes: int,
    ) -> None:
        console = Console()
        if not rows:
            console.print(f"No SSP Prometheus metrics found for scope={scope}, window={minutes}m")
            return

        table = Table(
            Column(header="Hostname", max_width=40),
            *[
                Column(header=SSP_STATS_METRICS[metric_key]["title"], max_width=24)
                for metric_key in metric_keys
            ],
        )
        for row in rows:
            table.add_row(
                row["hostname"],
                *[self._format_prometheus_value(row.get(metric_key)) for metric_key in metric_keys],
            )
        console.print(table)

    def _format_prometheus_value(self, value: Any) -> str:
        if value is None:
            return "-"
        try:
            return f"{float(value):.2f}"
        except (TypeError, ValueError):
            return str(value)

    def _determine_node_status(
        self,
        state: str,
        allocated_gpu: int,
        allocated_cpu: int,
        allocated_memory: str,
    ) -> NodeStatus:
        """Determine node status based on state and resource allocation.

        Args:
            state: Node state from API
            allocated_gpu: Allocated GPU count
            allocated_cpu: Allocated CPU count
            allocated_memory: Allocated memory in GB

        Returns:
            NodeStatus: IDLE (no tasks), MIXED (has tasks), or DRAIN (unavailable)
        """
        # Check if node is unavailable based on state
        if state in ("NotReady", "SchedulingDisabled"):
            return NodeStatus.DRAIN

        # Check if node is idle based on resource allocation
        has_allocated_resources = (
            allocated_gpu > 0
            or allocated_cpu > 0
            or int(allocated_memory) > 0
        )

        if has_allocated_resources:
            return NodeStatus.MIXED
        else:
            return NodeStatus.IDLE

    def get_node_info(self, /, node: str, *, out: Path | None = None, verbose=False) -> NodeSchema:
        """Get detailed information about a specific node."""
        logger.warning("SSP 平台暂不支持获取单个节点详细信息")
        return NodeSchema(
            name=node,
            total_gpu=0,
            total_cpu=0,
            total_memory="0",
            status=NodeStatus.UNRECORGNIZED,
        )

    # CLI interface methods

    def run_cli(
        self,
        *cmd: Annotated[str, Parameter(allow_leading_hyphen=True)],
        run_params: SSPRunParams | None = None,
    ) -> JobSchema:
        """创建并运行训练任务"""
        if run_params is None:
            run_params = SSPRunParams()
        run_params.cmd = " ".join(cmd)
        return self.run(run_params)

    def list_cli(
        self,
        *,
        group: str | None = None,
        user: Annotated[str | None, Parameter(name=["--user", "-u"])] = None,
        partition: Annotated[str | None, Parameter(name=["-p", "--partition"])] = None,
        status: Annotated[JobStatus | None, Parameter(name=["--status", "-s"])] = None,
        regex: Annotated[str | None, Parameter(help="正则表达式，用于过滤 job 任务名称")] = None,
        num: Annotated[int, Parameter(help="展示的 job 数量")] = 20,
        out: Annotated[Path | None, Parameter(name=["--out", "-o"])] = None,
        verbose: Annotated[bool, Parameter(name=["--verbose", "-v"])] = True,
        workspace: Annotated[str | None, Parameter(name=["-w", "--workspace"])] = None,
    ):
        """获取训练任务列表"""
        # When output file is specified, disable verbose to avoid stdout clutter and don't return
        actual_verbose = verbose and (out is None)
        result = self.list_jobs(
            group=group,
            user=user,
            partition=partition,
            status=status,
            regex=regex,
            num=num,
            out=out,
            verbose=actual_verbose,
            workspace=workspace,
        )
        # Only return result when not writing to file (to avoid cyclops printing it)
        if out is None:
            return result

    def stop_cli(
        self,
        job_id: Annotated[str | None, Parameter(name=["--job-id", "-j"])] = None,
        *,
        regex: Annotated[str | None, Parameter(help="正则表达式，用于过滤 job 任务名称")] = None,
        group: Annotated[str | None, Parameter(name=["--group", "-g"])] = None,
        user: Annotated[str | None, Parameter(name=["--user", "-u"])] = None,
        partition: Annotated[SSPPartition | None, Parameter(name=["-p", "--partition"])] = None,
        status: Annotated[JobStatus | None, Parameter(name=["--status", "-s"])] = None,
        confirm: Annotated[bool, Parameter(name=["--confirm", "-c"])] = False,
    ) -> None:
        """批量停止训练任务.

        Examples:
          clusterx stop my-job-id           # Stop specific job
          clusterx stop -j my-job-id        # Same as above
          clusterx stop --regex test.*      # Stop all matching jobs
        """
        self.stop(
            job_id=job_id,
            regex=regex,
            group=group,
            user=user,
            partition=partition,
            status=status,
            confirm=confirm,
        )

    def get_log_cli(
        self,
        job_id: Annotated[str, Parameter(help="Job ID")],
        streaming: Annotated[bool, Parameter(help="实时流式日志")] = False,
        lines: Annotated[int | None, Parameter(help="日志显示行数")] = None,
    ):
        """获取训练任务日志"""
        if streaming:
            # Note: Streaming is not implemented for SSP
            logger.warning("Streaming is not supported for SSP, showing current logs")

        logs = self.get_log(job_id, lines=lines)
        print(logs)

    def stats_node_cli(
        self,
        queue: Annotated[
            str | None,
            Parameter(help="队列名；不传时使用配置文件中的 queue/partition", name=["-q", "--queue"]),
        ] = None,
        *,
        cluster: Annotated[
            str | None,
            Parameter(help="集群名，优先级高于配置文件中的 cluster", name=["-C", "--cluster-name"]),
        ] = None,
        scope: Annotated[
            str | None,
            Parameter(help="Prometheus 指标查询范围: workspace/cluster/queue/job"),
        ] = None,
        metric: Annotated[
            str | None,
            Parameter(help="Prometheus 指标: gpu-util/gpu-memory-util/gpu-power/gpu-temp/all"),
        ] = None,
        minutes: Annotated[
            int,
            Parameter(help="Prometheus 指标查询最近 N 分钟"),
        ] = 5,
        step: Annotated[
            int,
            Parameter(help="Prometheus 查询步长秒数，预留给 range 查询"),
        ] = 30,
        job: Annotated[
            str | None,
            Parameter(help="job 范围查询的 workload/job 名称"),
        ] = None,
        out: Annotated[Path | None, Parameter(name=["--out", "-o"])] = None,
        verbose: Annotated[bool, Parameter(name=["--verbose", "-v"])] = True,
    ):
        """获取节点状态统计或 SSP Prometheus 指标.

        Examples:
          clusterx stats
          clusterx stats -q my-queue
          clusterx stats --metric all -q my-queue
          clusterx stats --scope job --job clusterx-ssp-test-06091520
        """
        if metric is not None or scope is not None or job is not None:
            result = self.stats_prometheus(
                scope=scope or "queue",
                metric=metric or "all",
                minutes=minutes,
                step=step,
                cluster=cluster,
                queue=queue,
                job=job,
                out=out,
                verbose=verbose and out is None,
            )
            if out is None:
                return result
            return None

        self.stats_node(queue=queue, cluster=cluster, out=out, verbose=verbose)

    def get_job_info_cli(self, /, job_id: str, verbose=True) -> JobSchema:
        """获取训练任务详情"""
        return self.get_job_info(job_id, verbose=verbose)

    # Async methods (placeholders)

    async def async_get_log(self, job_id: str, lines: int | None = None) -> str:
        """get_log 异步版本."""
        # For SSP, we use sync implementation
        return self.get_log(job_id, lines)

    async def async_get_job_info(self, /, job_id: str, verbose=False) -> JobSchema:
        """get_job_info 异步版本."""
        # For SSP, we use sync implementation
        return self.get_job_info(job_id, verbose)
