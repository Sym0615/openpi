import json
import os
from jinja2 import environment
import urllib3
import json
from pathlib import Path
from typing import Annotated, cast
import uuid
from concurrent.futures import ThreadPoolExecutor

from cyclopts import Parameter
from pydantic import model_validator
from rich import print
from rich.console import Console
from rich.prompt import Confirm
from rich.table import Column, Table

from clusterx.logger import getLogger

from ..base import (
    BaseCluster,
    BaseRunParams,
    JobSchema,
    JobStatus,
    NodeSchema,
    NodeStatus,
)
from .k8s_info import K8sPartitionEnum  # keep type aliases for CLI compatibility
from .npu_template import (
    JOB_NAME_KEY,
    get_job_memory,
    npu_volcano_template,
    get_job_name,
    get_job_user,
    get_num_cpus,
    get_num_gpus,
    get_cmd,
    get_num_nodes,
    SUBMITTER_KEY,
    GROUP,
    VERSION,
)

from kubernetes import client as k8s_client, config as k8s_config
from kubernetes.client import ApiException
import re


def normalize_label(name: str, max_len: int = 63) -> str:
    name = name.lower()
    name = re.sub(r'[^a-z0-9-]', '-', name)
    name = re.sub(r'-+', '-', name)
    name = name.strip('-')
    if len(name) > max_len:
        name = name[:max_len].rstrip('-')
    if not name:
        raise ValueError("cannot normalize to a valid DNS-1123 label")
    return name + "-"


STATUS_MAPPING = {
    # Pod phases to JobStatus mapping (used as fallback)
    "Pending": JobStatus.QUEUING,
    "Aborting": JobStatus.FAILED,
    "Aborted": JobStatus.FAILED,
    "Running": JobStatus.RUNNING,
    "Restarting": JobStatus.QUEUING,
    "Completing": JobStatus.SUCCEEDED,
    "Completed": JobStatus.SUCCEEDED,
    "Terminating": JobStatus.STOPPED,
    "Terminated": JobStatus.STOPPED,
    "Failed": JobStatus.FAILED,
}


@Parameter(name="*")
class K8sParams(BaseRunParams[K8sPartitionEnum]):
    delete_exist: Annotated[bool, Parameter(help="是否删除重名的任务")] = False
    partition: Annotated[K8sPartitionEnum | None, Parameter(show=False)] = None
    mount: Annotated[
        str | None,
        Parameter(help="hostPath 挂载，例如 /data:/mnt/data, 多个用逗号分隔；非 hostPath 将被忽略"),
    ] = None
    image: Annotated[str | None, Parameter(help="镜像 url，默认使用 `~/.config/cluster.yaml` 设置的镜像")] = None
    tmpdir: Annotated[str | None, Parameter(show=False)] = None
    # TODO:
    include: Annotated[str | None, Parameter(show=True, help="逗号分隔的节点名：host-10-140-215-237,host-10-140-215-236")] = None
    exclude: Annotated[str | None, Parameter(show=True, help="逗号分隔的节点名：host-10-140-215-237,host-10-140-215-236")] = None
    priority: Annotated[int, Parameter(help="优先级：1=normal，2=high，3=highest")] = 1
    retry: Annotated[bool, Parameter(help="任务失败时自动重启")] = False
    num_spods: Annotated[int | None, Parameter(help="超节点数，只对 npu 有效")] = None
    preemptible: Annotated[bool | None, Parameter(show=False)] = None
    shm_per_task: Annotated[int, Parameter(help="每个任务使用的shm共享内存")] = 64
    is_privileged: Annotated[bool, Parameter(help="是否发起特权容器")] = True

    @model_validator(mode="after")
    def validate_k8s_priority(self):
        if self.priority not in (1, 2, 3):
            raise ValueError("k8s priority 仅支持 1、2、3，分别对应 normal、high、highest")
        return self

    @property
    def max_retry(self) -> int:
        return 3 if self.retry else 1



logger = getLogger("clusterx.launcher.k8s")


class K8sCluster(BaseCluster):
    """Kubernetes Job 任务发布器."""

    def __init__(self):
        # Load config

        # Resolve namespace

        from clusterx.config import CLUSTERX_CONFIG, K8sConfig

        cluster_cfg = getattr(CLUSTERX_CONFIG, CLUSTERX_CONFIG.default)

        assert cluster_cfg is not None
        self.clusterx_cfg = cast(K8sConfig, cluster_cfg)

        # verify_ssl=False will trigger warning of urlib3
        urllib3.disable_warnings()
        kubeconfig = os.getenv("KUBECONFIG", self.clusterx_cfg["kubeconfig"])
        k8s_config.load_kube_config(kubeconfig)
        cfg = k8s_client.Configuration.get_default_copy()
        cfg.verify_ssl = False

        self.api_client = k8s_client.ApiClient(configuration=cfg)
        self.core = k8s_client.CoreV1Api(self.api_client)
        self.namespace = "default"
        self.batch = k8s_client.BatchV1Api(self.api_client)

        self.custom_object_api = k8s_client.CustomObjectsApi(self.api_client)

    def run(self, run_params: K8sParams) -> JobSchema:
        job_name = run_params.job_name

        cmd = self._build_command(
            run_params.cmd,
            run_params.no_env,
            num_nodes=run_params.num_nodes,
            num_spods=run_params.num_spods,
            is_privileged=run_params.is_privileged,
        )
        image = self._get_image(run_params)
        # partition = self._get_partition(run_params)
        mount_list = self._get_mount(run_params)

        max_retry = run_params.max_retry

        envs_list = run_params.environment or []
        envs_dict: dict[str, str] = {}
        for env_str in envs_list:
            key, value = env_str.split("=", 1)
            envs_dict[key] = value


        body_str = npu_volcano_template.render(
            num_nodes=run_params.num_nodes,
            submitter=self.clusterx_cfg["user"],
            max_retry=max_retry,
            cmd=cmd,
            image=image,
            num_cpus=run_params.cpus_per_task,
            num_gpus=run_params.gpus_per_task,
            num_spods=run_params.num_spods,
            memory=run_params.memory_per_task,
            shm=run_params.shm_per_task,
            mount_list=mount_list,
            job_name=normalize_label(job_name),
            image_secret_key=self.clusterx_cfg["image_secret_key"],
            privileged=run_params.is_privileged,
            include=run_params.include,
            exclude=run_params.exclude,
            environment=envs_dict,
            priority=run_params.priority,
        )
        body = json.loads(body_str)


        job = self.custom_object_api.create_namespaced_custom_object(
            group=GROUP,
            version=VERSION,
            namespace=body["metadata"]["namespace"],
            plural="jobs",
            body=body,
        )
        job_schema = self.get_job_info(job["metadata"]["name"])
        logger.info(job_schema.model_dump_json(indent=4))
        return job_schema

    def stop(
        self,
        *,
        job_id: str | None = None,
        regex: str | None = None,
        group: str | None = None,
        user: str | None = None,
        partition: K8sPartitionEnum | None = None,
        status: JobStatus | None = None,
        confirm: bool = False,
        check_user: bool = True,
    ) -> None:
        status_list = self._get_k8s_status(status)
        if group is not None:
            raise NotImplementedError("暂不支持按照分组删除任务")

        if partition is not None:
            raise NotImplementedError("暂不支持按照分区删除任务")

        if regex is not None:
            raise NotImplementedError("暂不支持按照正则表达式删除任务")

        if job_id is not None:
            self._delete_job(job_id)
            logger.info(f"任务 {job_id} 已停止")
            return

        jobs = self.custom_object_api.list_namespaced_custom_object(
            group=GROUP,
            version=VERSION,
            namespace=self.namespace,
            plural="jobs",
            label_selector=f"{SUBMITTER_KEY}={user}",
        )["items"]

        filtered_jobs = []
        for job in jobs:
            if status is not None and job["status"]["state"]["phase"] not in status_list:
                continue
            filtered_jobs.append(job)

        if not filtered_jobs:
            logger.info("没有需要被停止的任务")
            return

        if not filtered_jobs:
            logger.info("未找到匹配的任务")
            return

        if confirm:
            console = Console()
            confirm_check = Confirm("是否删除以上任务？", console=console)

            table = Table(
                Column("任务名", min_width=40, max_width=80, overflow="ellipsis"),
                Column("任务状态", max_width=20),
                Column("用户名", max_width=20),
                Column("所属分区", max_width=20),
            )
            for job in filtered_jobs:
                table.add_row(
                    job.metadata.name or "Unknown",
                    str(self._get_job_status(job)),
                    get_job_user(job),
                    "",  # TODO:
                )
            console.print(table, highlight=True)
            if not confirm_check.ask():
                return

        for job in filtered_jobs:
            self._delete_job(job.metadata.name or "")

    def stats_node_cli(
        self,
        partition: Annotated[K8sPartitionEnum, Parameter(help="分区名")],
        /,
        *,
        out: Annotated[Path | None, Parameter(name=["--out", "-o"])] = None,
        verbose: Annotated[bool, Parameter(name=["--verbose", "-v"])] = True,
    ):
        self.stats_node(partition.value, out=out, verbose=verbose)

    def stats_node(self, /, partition: str, *, out: Path | None = None, verbose=False) -> list[NodeSchema]:
        raise NotImplementedError()

    def get_node_info(self, /, node: str, *, out: Path | None = None, verbose=False) -> NodeSchema:
        raise NotImplementedError()

    def list_jobs(
        self,
        *,
        group: str | None = None,
        user: str | None = None,
        partition: K8sPartitionEnum | None = None,
        status: JobStatus | None = None,
        regex: str | None = None,
        num: int = 20,
        out: Path | None = None,
        verbose: bool = False,
    ) -> list[JobSchema]:
        if regex is not None:
            raise NotImplementedError("暂不支持按照正则表达式列出任务")

        if group is not None:
            raise NotImplementedError("暂不支持按照分组列出任务")

        if partition is not None:
            raise NotImplementedError("暂不支持按照分区列出任务")

        k8s_status_list = self._get_k8s_status(status) if status is not None else []

        jobs = self.custom_object_api.list_namespaced_custom_object(
            group=GROUP,
            version=VERSION,
            namespace=self.namespace,
            plural="jobs",
            label_selector=f"{SUBMITTER_KEY}={user}" if user else None,
        )["items"]

        job_schemas: list[JobSchema] = []
        jobs = sorted(jobs, key=lambda j: j["metadata"]["creationTimestamp"], reverse=True)
        for job in jobs:
            if status is not None and job["status"]["state"]["phase"] not in k8s_status_list:
                continue

            job_schema = self._get_job_info(job)
            job_schemas.append(job_schema)

            if len(job_schemas) >= num:
                break

        if verbose:
            table = Table(
                Column("任务名", min_width=40, max_width=80, overflow="ellipsis"),
                Column("任务状态", max_width=20),
                Column("用户名", max_width=20),
                Column("节点数", max_width=10),
                Column("每节点 GPU", max_width=10),
                Column("每节点 CPU", max_width=10),
                Column("每节点内存(GB)", max_width=15),
                # Column("命令", min_width=40, max_width=80, overflow="ellipsis"),
                # Column("提交时间", max_width=20),
                # Column("开始时间", max_width=20),
            )
            for job_schema in job_schemas[:num]:
                table.add_row(
                    job_schema.job_id,
                    str(job_schema.status),
                    job_schema.user or "Unknown",
                    str(job_schema.num_nodes),
                    str(job_schema.gpus_per_node),
                    str(job_schema.cpus_per_node),
                    str(job_schema.memory),
                    # job_schema.cmd or "Unknown",
                    # str(job_schema.submit_time) if job_schema.submit_time else "Unknown",
                    # str(job_schema.start_time) if job_schema.start_time else "Unknown",
                )
            if verbose:
                print(table)

            if out is not None:
                out.parent.mkdir(exist_ok=True, parents=True)
                with out.open("w") as f:
                    json.dump([j.model_dump() for j in job_schemas], f, indent=4)
        return job_schemas

    def get_job_info(self, /, job_id: str, verbose=False) -> JobSchema:
        job = self.custom_object_api.get_namespaced_custom_object(
            group=GROUP,
            version=VERSION,
            namespace=self.namespace,
            plural="jobs",
            name=job_id,
        )

        job_schema = self._get_job_info(job)

        if verbose:
            print(job_schema)
        return job_schema

    def _get_job_info(self, job: dict) -> JobSchema:
        job_id = get_job_name(job)
        raw_pods = self.core.list_namespaced_pod(
            namespace=self.namespace,
            label_selector=f"volcano.sh/job-name={job_id}",
        ).items

        nodes = [pod.status.pod_ip for pod in raw_pods if pod.status.pod_ip is not None]
        job_schema = JobSchema(
            job_id=job_id,
            user=get_job_user(job),
            gpus_per_node=get_num_gpus(job),
            cpus_per_node=get_num_cpus(job),
            memory=get_job_memory(job),
            status=self._get_job_status(job),
            num_nodes=get_num_nodes(job),
            partition="",
            job_name=job_id,
            cmd=get_cmd(job),
            nodes=nodes,
            nodes_ip=nodes,
            # submit_time=,  # TODO:
            # start_time=,  # TODO:
        )
        return job_schema

    def get_log(self, job_id: str, lines: int | None = None) -> str:
        # 列出属于该 volcano job 的 pods
        pods = self.core.list_namespaced_pod(
            namespace=self.namespace,
            label_selector=f"{JOB_NAME_KEY}={job_id}",
        ).items

        if not pods:
            return f"No pods found for job {job_id}"

        parts: list[str] = []
        # 按名字排序，保证输出顺序稳定
        pods = sorted(pods, key=lambda p: p.metadata.name or "")
        for pod in pods:
            pod_name = pod.metadata.name or "<unknown>"
            # 同时收集 initContainers 和 regular containers 的日志
            container_names = []
            if pod.spec and getattr(pod.spec, "containers", None):
                container_names += [c.name for c in pod.spec.containers]

            if not container_names:
                parts.append(f"== Pod: {pod_name} (no containers) ==")
                continue

            for cname in container_names:
                try:
                    # 如果指定了 lines，使用 tail_lines 参数；否则获取全部日志
                    log_kwargs = {
                        "name": pod_name,
                        "namespace": self.namespace,
                        "container": cname,
                        "timestamps": True,
                    }
                    if lines is not None and lines > 0:
                        log_kwargs["tail_lines"] = lines
                    log = self.core.read_namespaced_pod_log(**log_kwargs)
                except ApiException as e:
                    logger.warning(f"Failed to fetch log for {pod_name}/{cname}: {e}")
                    continue
                header = f"== Pod: {pod_name} | Container: {cname} ==\n"
                parts.append(header + (log or ""))

        return "\n\n".join(parts)

    async def async_get_job_info(self, /, job_id: str, verbose=False) -> JobSchema:
        raise NotImplementedError()

    def run_cli(
        self, *cmd: Annotated[str, Parameter(allow_leading_hyphen=True)], run_params: K8sParams | None = None
    ) -> JobSchema:
        if run_params is None:
            run_params = K8sParams()
        run_params.cmd = " ".join(cmd)
        return self.run(run_params)

    def list_cli(
        self,
        *,
        group: str | None = None,
        user: Annotated[str | None, Parameter(name=["--user", "-u"])] = None,
        partition: Annotated[K8sPartitionEnum | None, Parameter(name=["-p", "--partition"])] = None,
        status: Annotated[JobStatus | None, Parameter(name=["--status", "-s"])] = None,
        regex: Annotated[str | None, Parameter(help="匹配任务名的正则表达式")] = None,
        num: Annotated[int, Parameter(help="匹配任务名的正则表达式")] = 20,
        out: Annotated[Path | None, Parameter(name=["--out", "-o"])] = None,
        verbose: Annotated[bool, Parameter(name=["--verbose", "-v"])] = True,
    ):
        self.list_jobs(
            group=group, user=user, partition=partition, status=status, regex=regex, num=num, out=out, verbose=verbose
        )

    def stop_cli(
        self,
        *,
        job_id: Annotated[str | None, Parameter(name=["--job-id", "-j"])] = None,
        regex: Annotated[str | None, Parameter(help="匹配任务名的正则表达式")] = None,
        group: Annotated[str | None, Parameter(name=["--group", "-g"])] = None,
        user: Annotated[str | None, Parameter(name=["--user", "-u"])] = None,
        partition: Annotated[K8sPartitionEnum | None, Parameter(name=["-p", "--partition"])] = None,
        status: Annotated[JobStatus | None, Parameter(name=["-status", "-s"])] = None,
        confirm: Annotated[bool, Parameter(name=["--confirm", "-c"])] = False,
        check_user: bool = True,
    ) -> None:
        self.stop(
            job_id=job_id,
            regex=regex,
            group=group,
            user=user,
            partition=partition,
            status=status,
            confirm=confirm,
            check_user=check_user,
        )

    def get_log_cli(
        self,
        job_id: Annotated[str, Parameter(help="任务 ID")],
        streaming: Annotated[bool, Parameter(help="是否持续捕获运行中日志的输出")] = False,
    ):
        if streaming:
            raise NotImplementedError("暂不支持日志流式输出")
        else:
            print(self.get_log(job_id))

    def _get_job_status(self, job: dict) -> JobStatus:
        if "status" not in job or "state" not in job["status"]:
            return JobStatus.QUEUING

        status = job["status"]["state"]["phase"]
        for k, v in STATUS_MAPPING.items():
            if k.lower() == status.lower():
                return v
        else:
            return JobStatus.UNRECORGNIZED

    def _delete_job(self, job_name: str):
        def _delete_pod(pod):
            self.core.delete_namespaced_pod(
                name=pod.metadata.name or "",
                namespace=self.namespace,
                body=k8s_client.V1DeleteOptions(),
            )

        with ThreadPoolExecutor(max_workers=10) as executor:
            # 删除 Volcano Job
            # 删除相关的 Pods
            pods = self.core.list_namespaced_pod(
                namespace=self.namespace,
                label_selector=f"{JOB_NAME_KEY}={job_name}",
            ).items
            futures = [executor.submit(_delete_pod, pod) for pod in pods]
            for future in futures:
                try:
                    future.result()
                except ApiException as e:
                    if e.status != 404:
                        raise

    def _build_pytorch_ddp_cmd(self):
        cmd = (
            "export MASTER_ADDR=${MASTER_ADDR:-$HOSTNAME} && "
            "export MASTER_PORT=${MASTER_PORT:-6000} && "
            "export WORLD_SIZE=${WORLD_SIZE:-$NODE_COUNT} && "
            "export RANK=${RANK:-$NODE_RANK} && "
        )
        return cmd

    def _build_command(self, cmd: str, no_env: bool, num_nodes: int, num_spods: int, is_privileged: bool) -> str:
        _cmd = self._build_pytorch_ddp_cmd()
        exclude = {"LC_ALL"}
        if not no_env:
            env_cmd = ""
            inherited_env = {k: v for k, v in os.environ.items() if v != ""}
            for k, v in inherited_env.items():
                if k in exclude:
                    continue
                env_cmd += f"export {k}='{v}' &&"
            _cmd += env_cmd
            _cmd += f"cd {os.getcwd()} && "
        _cmd += "source /usr/local/Ascend/ascend-toolkit/set_env.sh && "
        _cmd += "export LD_LIBRARY_PATH=/usr/local/Ascend/driver/lib64:/usr/local/Ascend/driver/lib64/driver:/usr/local/Ascend/driver/lib64/common:$LD_LIBRARY_PATH && "
        _xtuner_cmd = (
            "export PYTORCH_NPU_ALLOC_CONF=expandable_segments:True && "
            "export MULTI_STREAM_MEMORY_REUSE=2 && "
            "export HCCL_RDMA_TC=132 && "
            "export HCCL_CONNECT_TIMEOUT=3600 && "
            "export HCCL_BUFFSIZE=512 && "
            "export TORCH_HCCL_ZERO_COPY=1 && "
            r"export GPUS_PER_NODE=$(echo $ASCEND_VISIBLE_DEVICES | tr ',' '\n' | wc -l) && "
            "export GLOO_SOCKET_IFNAME=eth0 && "
            "export ASCEND_WORK_PATH=/tmp && "
        )
        if num_spods and num_spods > 1:
            assert num_nodes >= num_spods, (
                f"num_nodes({num_nodes}) must be greater than or equal to num_spods({num_spods})"
            )
            assert num_nodes % num_spods == 0, (
                f"num_nodes({num_nodes}) must be divisible by num_spods({num_spods})"
            )
            _xtuner_cmd += (
                f"export NODES_PER_LOGIC_NODE={num_nodes // num_spods} && "
                "export HCCL_LOGIC_SUPERPOD_ID=$(($RANK/${NODES_PER_LOGIC_NODE})) && "
            )
        if is_privileged:
            # 特权容器下可以打开下面的魔法指令缓解高并发任务下 Gloo & HCCL 链接报错的问题
            _xtuner_cmd += (
                "sysctl -w net.ipv4.tcp_max_syn_backlog=65536 && "
                "sysctl -w net.core.somaxconn=65536 && "
                "sysctl -w net.ipv4.ip_local_reserved_ports=60000-60015 && "
            )
        _cmd += _xtuner_cmd

        cmd = _cmd + cmd
        return cmd

    def _get_image(self, run_params: K8sParams) -> str:
        image = run_params.image or self.clusterx_cfg["image"]
        if not image:
            raise RuntimeError("请设置镜像地址")
        return image

    def _get_mount(self, run_params: K8sParams) -> list[dict]:
        default_mount = list(self.clusterx_cfg.get("mount", [])) or []
        if run_params.mount is not None:
            default_mount += run_params.mount.split(",")
        # keep only hostPath mounts
        cleaned = []
        for m in default_mount:
            m = m.strip()
            if not m or ":" not in m:
                continue
            left, right = m.split(":", 1)
            if left.startswith("pvc") or left.startswith("/"):
                cleaned.append({"source": left, "target": right, "name": left.replace("/", "-").strip("-")})
            else:
                logger.warning(f"忽略非 hostPath 或 PVC 挂载: {m}")
        return cleaned

    def _normalize_node_list(self, nodes: str | None) -> list[str]:
        if not nodes:
            return []
        return [f"node/{node}" if not node.startswith("node/") else node for node in nodes.split(",") if node]

    async def async_get_log(self, job_id: str, lines: int | None = None) -> str:
        # k8s 的异步日志获取暂未实现，使用同步版本
        return self.get_log(job_id, lines=lines)

    def _get_k8s_status(self, status: JobStatus | None) -> list[str]:
        if status is None:
            return []

        ret = []
        for k, v in STATUS_MAPPING.items():
            if v == status:
                ret.append(k)
        return ret
