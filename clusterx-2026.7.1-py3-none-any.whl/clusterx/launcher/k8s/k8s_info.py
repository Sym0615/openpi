from clusterx.utils import StrEnum



K8sPartitionEnum = StrEnum(
    "K8sPartition",
    [],
)
