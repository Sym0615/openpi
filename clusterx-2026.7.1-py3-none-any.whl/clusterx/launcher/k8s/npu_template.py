from jinja2 import Environment
import json

env = Environment()
SUBMITTER_KEY = "lepton.sensetime.com/submitter"
JOB_NAME_KEY = "volcano.sh/job-name"
GROUP = "batch.volcano.sh"
VERSION = "v1alpha1"


def get_job_user(job: dict):
    return job["metadata"]["labels"].get("lepton.sensetime.com/submitter", "unknown")


def get_num_gpus(job: dict):
    task0 = job["spec"].get("tasks", [])[0]
    containers0 = task0.get("template", {}).get("spec", {}).get("containers", [])
    resources0 = containers0[0].get("resources", {})
    requests0 = resources0.get("requests", {})
    num_gpus = int(requests0.get("huawei.com/Ascend910", 0))
    return num_gpus


def get_num_cpus(job: dict):
    task0 = job["spec"].get("tasks", [])[0]
    containers0 = task0.get("template", {}).get("spec", {}).get("containers", [])
    resources0 = containers0[0].get("resources", {})
    requests0 = resources0.get("requests", {})
    num_cpus = int(requests0.get("cpu", 0))
    return num_cpus


def get_num_nodes(job: dict):
    num_nodes = 0
    for task in job["spec"].get("tasks", []):
        num_nodes += int(task.get("replicas", 0))
    return num_nodes


def get_job_name(job: dict):
    return job["metadata"].get("name", "unknown")


def get_job_memory(job: dict) -> str:
    task0 = job["spec"].get("tasks", [])[0]
    containers0 = task0.get("template", {}).get("spec", {}).get("containers", [])
    resources0 = containers0[0].get("resources", {})
    requests0 = resources0.get("requests", {})
    memory = requests0.get("memory", "unknown")
    return memory


def get_image(job: dict) -> str:
    task0 = job["spec"].get("tasks", [])[0]
    containers0 = task0.get("template", {}).get("spec", {}).get("containers", [])
    image = containers0[0].get("image", "unknown")
    return image


def get_cmd(job: dict) -> str:
    task0 = job["spec"].get("tasks", [])[0]
    containers0 = task0.get("template", {}).get("spec", {}).get("containers", [])
    cmd = containers0[0].get("args", ["unknown"])[0]
    return cmd


def _get_shared_memory(memory: int):
    return min(64, memory // 4)


def _get_die_per_pod(gpus_per_task: int, num_nodes: int, num_spods: int | None):
    if num_spods is None:
        die_per_pod = num_nodes * gpus_per_task
        assert die_per_pod <= 768, (
            f"The `num_nodes({num_nodes}) x gpus_per_task ({gpus_per_task}) = {die_per_pod}` dies per pod exceeds the limit of 768."
            f"For 910C, the maximum dies per pod is 768, please set `num_spods` to ensure that `num_spods x 768` is "
            f"larger than or equal to the total number of {die_per_pod}."
        )
    else:
        die_per_pod = gpus_per_task * num_nodes / num_spods
    return int(die_per_pod)


def _get_policies(max_retry: int):
    if max_retry > 1:
        policies = [{"action": "RestartJob", "event": "PodFailed"}, {"action": "RestartJob", "event": "PodEvicted"}]
    else:
        policies = [{"action": "RestartJob", "event": "PodEvicted"}]
    return json.dumps(policies)


def _get_node(node_list_str: str | None):
    if node_list_str is not None:
        return json.dumps(node_list_str.split(","))
    else:
        return json.dumps([])


_K8S_PRIORITY_TO_CLASS = {1: "normal", 2: "high", 3: "highest"}


def _priority_class_name(priority: int) -> str:
    if priority not in _K8S_PRIORITY_TO_CLASS:
        raise ValueError(
            f"k8s priority 仅支持 1、2、3（对应 normal、high、highest），收到: {priority}"
        )
    return _K8S_PRIORITY_TO_CLASS[priority]


env.globals["_get_die_per_pod"] = _get_die_per_pod
env.globals["_get_shared_memory"] = _get_shared_memory
env.globals["_get_policies"] = _get_policies
env.globals["_get_node"] = _get_node
env.globals["_priority_class_name"] = _priority_class_name


_npu_template_str = """{
    {% set shm = shm if shm is defined else _get_shared_memory(memory) %}
    "apiVersion": "batch.volcano.sh/v1alpha1",
    "kind": "Job",
    "metadata": {
        {% if num_gpus > 1 %}
        "annotations": {"sp-block": "{{ _get_die_per_pod(num_gpus, num_nodes, num_spods) }}"},
        {% endif %}
        "generateName": "{{ job_name }}",
        "labels": {
            "lepton.sensetime.com/framework-type": "PyTorch",
            "lepton.sensetime.com/submitter": "{{ submitter }}",
            "ring-controller.atlas": "ascend-910b"
        },
        "namespace": "default"
    },
    "spec": {
        "maxRetry": {{ max_retry }},
        "plugins": {
            "hcclrank": [],
            "pytorch": ["--master=master", "--worker=worker", "--port=23456"],
            "svc": []
        },
        "policies": {{ _get_policies(max_retry) }},
        "priorityClassName": "{{ _priority_class_name(priority) }}",
        "queue": "default",
        "schedulerName": "volcano",
        "minAvailable": {{ num_nodes }},
        "tasks": [
            {%- if num_nodes == 1 %}
            {
                "maxRetry": {{ max_retry }},
                "minAvailable": 1,
                "name": "worker",
                "replicas": 1,
                "template": {
                    "metadata": {
                        "labels": {
                            "lepton.sensetime.com/submitter": "{{ submitter }}",
                            "ring-controller.atlas": "ascend-910b"
                        }
                    },
                    "spec": {
                        "affinity": {
                            "nodeAffinity": {
                                "requiredDuringSchedulingIgnoredDuringExecution": {
                                    "nodeSelectorTerms": [
                                        {
                                            "matchExpressions": [
                                                {%- if include %}
                                                {
                                                    "key": "kubernetes.io/hostname",
                                                    "operator": "In",
                                                    "values": {{ _get_node(include) }}
                                                },
                                                {%- endif %}
                                                {%- if exclude %}
                                                {
                                                    "key": "kubernetes.io/hostname",
                                                    "operator": "NotIn",
                                                    "values": {{ _get_node(exclude) }}
                                                },
                                                {%- endif %}
                                                {
                                                    "key": "resource.compute.sensecore.cn/machine-type",
                                                    "operator": "In",
                                                    "values": ["h2ls.ru.k10"]
                                                }
                                            ]
                                        }
                                    ]
                                }
                            }
                        },
                        "containers": [
                            {
                                "args": ["{{ cmd }}"],
                                "command": ["bash", "-c"],
                                "image": "{{ image }}",
                                "imagePullPolicy": "IfNotPresent",
                                "name": "worker",
                                "resources": {
                                    {% if num_gpus > 1 %}
                                    "requests": {"cpu": "{{ num_cpus }}", "huawei.com/Ascend910": "{{ num_gpus }}", "memory": "{{ memory }}Gi"},
                                    "limits": {"cpu": "{{ num_cpus }}", "huawei.com/Ascend910": "{{ num_gpus }}", "memory": "{{ memory }}Gi"}
                                    {% else %}
                                    "requests": {"cpu": "{{ num_cpus }}", "memory": "{{ memory }}Gi"},
                                    "limits": {"cpu": "{{ num_cpus }}", "memory": "{{ memory }}Gi"}
                                    {% endif %}
                                },
                                "securityContext": {
                                    "privileged": {{ privileged | tojson }}{% if privileged %},
                                    "capabilities": {
                                        "add": ["IPC_LOCK"]
                                    }{% endif %}
                                },
                                "volumeMounts": [
                                    {%- for mount in mount_list %}
                                    {"mountPath": "{{ mount.target }}", "name": "{{ mount.name }}"},
                                    {%- endfor %}
                                    {"mountPath": "/dev/shm", "name": "shm-data"}
                                ],
                                "env": [
                                    {%- for key, value in environment.items() %}
                                    {"name": "{{ key }}", "value": "{{ value }}"},
                                    {%- endfor %}
                                    {
                                        "name": "JOB_NAME",
                                        "valueFrom": {"fieldRef": {"fieldPath": "metadata.labels['volcano.sh/job-name']"}}
                                    },
                                    {
                                        "name": "ASCEND_VISIBLE_DEVICES",
                                        "valueFrom": {
                                            "fieldRef": {
                                                "fieldPath": "metadata.annotations['huawei.com/Ascend910']"
                                            }
                                        }
                                    }
                                ]
                            }
                        ],
                        "imagePullSecrets": [{"name": "{{ image_secret_key }}"}],
                        "nodeSelector": {"host-arch": "huawei-arm"},
                        "restartPolicy": "Never",
                        "volumes": [
                        {%- for mount in mount_list %}
                            {%- if mount.source.startswith('pvc') %}
                            {"persistentVolumeClaim": {"claimName": "{{ mount.source }}"}, "name": "{{ mount.name }}"},
                            {%- else %}
                            {"hostPath": {"path": "{{ mount.source }}"}, "name": "{{ mount.name }}"},
                            {%- endif %}
                        {%- endfor %}
                            {"emptyDir": {"medium": "Memory", "sizeLimit": "{{ shm }}Gi"}, "name": "shm-data"}
                        ]
                    }
                }
            }
            {%- else %}
            {
                "maxRetry": {{ max_retry }},
                "minAvailable": 1,
                "name": "master",
                "replicas": 1,
                "template": {
                    "metadata": {
                        "labels": {
                            "lepton.sensetime.com/submitter": "{{ submitter }}",
                            "ring-controller.atlas": "ascend-910b"
                        }
                    },
                    "spec": {
                        "affinity": {
                            "nodeAffinity": {
                                "requiredDuringSchedulingIgnoredDuringExecution": {
                                    "nodeSelectorTerms": [
                                        {
                                            "matchExpressions": [
                                                {%- if include %}
                                                {
                                                    "key": "kubernetes.io/hostname",
                                                    "operator": "In",
                                                    "values": {{ _get_node(include) }}
                                                },
                                                {%- endif %}
                                                {%- if exclude %}
                                                {
                                                    "key": "kubernetes.io/hostname",
                                                    "operator": "NotIn",
                                                    "values": {{ _get_node(exclude) }}
                                                },
                                                {%- endif %}
                                                {
                                                    "key": "resource.compute.sensecore.cn/machine-type",
                                                    "operator": "In",
                                                    "values": ["h2ls.ru.k10"]
                                                }
                                            ]
                                        }
                                    ]
                                }
                            }
                        },
                        "containers": [
                            {
                                "args": ["{{ cmd }}"],
                                "command": ["bash", "-c"],
                                "image": "{{ image }}",
                                "imagePullPolicy": "IfNotPresent",
                                "name": "master",
                                "resources": {
                                    {% if num_gpus > 1 %}
                                    "requests": {"cpu": "{{ num_cpus }}", "huawei.com/Ascend910": "{{ num_gpus }}", "memory": "{{ memory }}Gi"},
                                    "limits": {"cpu": "{{ num_cpus }}", "huawei.com/Ascend910": "{{ num_gpus }}", "memory": "{{ memory }}Gi"}
                                    {% else %}
                                    "requests": {"cpu": "{{ num_cpus }}", "memory": "{{ memory }}Gi"},
                                    "limits": {"cpu": "{{ num_cpus }}", "memory": "{{ memory }}Gi"}
                                    {% endif %}
                                },
                                "securityContext": {
                                    "privileged": {{ privileged | tojson }}{% if privileged %},
                                    "capabilities": {
                                        "add": ["IPC_LOCK"]
                                    }{% endif %}
                                },
                                "volumeMounts": [
                                    {%- for mount in mount_list %}
                                    {"mountPath": "{{ mount.target }}", "name": "{{ mount.name }}"},
                                    {%- endfor %}
                                    {"mountPath": "/dev/shm", "name": "shm-data"}
                                ],
                                "env": [
                                    {%- for key, value in environment.items() %}
                                    {"name": "{{ key }}", "value": "{{ value }}"},
                                    {%- endfor %}
                                    {
                                        "name": "JOB_NAME",
                                        "valueFrom": {"fieldRef": {"fieldPath": "metadata.labels['volcano.sh/job-name']"}}
                                    },
                                    {
                                        "name": "ASCEND_VISIBLE_DEVICES",
                                        "valueFrom": {
                                            "fieldRef": {
                                                "fieldPath": "metadata.annotations['huawei.com/Ascend910']"
                                            }
                                        }
                                    }
                                ]
                            }
                        ],
                        "imagePullSecrets": [{"name": "{{ image_secret_key }}"}],
                        "nodeSelector": {"host-arch": "huawei-arm"},
                        "restartPolicy": "Never",
                        "volumes": [
                        {%- for mount in mount_list %}
                            {%- if mount.source.startswith('pvc') %}
                            {"persistentVolumeClaim": {"claimName": "{{ mount.source }}"}, "name": "{{ mount.name }}"},
                            {%- else %}
                            {"hostPath": {"path": "{{ mount.source }}"}, "name": "{{ mount.name }}"},
                            {%- endif %}
                        {%- endfor %}
                            {"emptyDir": {"medium": "Memory", "sizeLimit": "{{ shm }}Gi"}, "name": "shm-data"}
                        ]
                    }
                }
            },
            {
                "maxRetry": {{ max_retry }},
                "minAvailable": {{ num_nodes - 1 }},
                "replicas": {{ num_nodes - 1 }},
                "name": "worker",
                "template": {
                    "metadata": {
                        "labels": {
                            "lepton.sensetime.com/submitter": "{{ submitter }}",
                            "ring-controller.atlas": "ascend-910b"
                        }
                    },
                    "spec": {
                        "affinity": {
                            "nodeAffinity": {
                                "requiredDuringSchedulingIgnoredDuringExecution": {
                                    "nodeSelectorTerms": [
                                        {
                                            "matchExpressions": [
                                                {%- if include %}
                                                {
                                                    "key": "kubernetes.io/hostname",
                                                    "operator": "In",
                                                    "values": {{ _get_node(include) }}
                                                },
                                                {%- endif %}
                                                {%- if exclude %}
                                                {
                                                    "key": "kubernetes.io/hostname",
                                                    "operator": "NotIn",
                                                    "values": {{ _get_node(exclude) }}
                                                },
                                                {%- endif %}
                                                {
                                                    "key": "resource.compute.sensecore.cn/machine-type",
                                                    "operator": "In",
                                                    "values": ["h2ls.ru.k10"]
                                                }
                                            ]
                                        }
                                    ]
                                }
                            }
                        },
                        "containers": [
                            {
                                "args": ["{{ cmd }}"],
                                "command": ["bash", "-c"],
                                "image": "{{ image }}",
                                "imagePullPolicy": "IfNotPresent",
                                "name": "worker",
                                "resources": {
                                    {% if num_gpus > 1 %}
                                    "requests": {"cpu": "{{ num_cpus }}", "huawei.com/Ascend910": "{{ num_gpus }}", "memory": "{{ memory }}Gi"},
                                    "limits": {"cpu": "{{ num_cpus }}", "huawei.com/Ascend910": "{{ num_gpus }}", "memory": "{{ memory }}Gi"}
                                    {% else %}
                                    "requests": {"cpu": "{{ num_cpus }}", "memory": "{{ memory }}Gi"},
                                    "limits": {"cpu": "{{ num_cpus }}", "memory": "{{ memory }}Gi"}
                                    {% endif %}
                                },
                                "securityContext": {
                                    "privileged": {{ privileged | tojson }}{% if privileged %},
                                    "capabilities": {
                                        "add": ["IPC_LOCK"]
                                    }{% endif %}
                                },
                                "volumeMounts": [
                                    {%- for mount in mount_list %}
                                    {"mountPath": "{{ mount.target }}", "name": "{{ mount.name }}"},
                                    {%- endfor %}
                                    {"mountPath": "/dev/shm", "name": "shm-data"}
                                ],
                                "env": [
                                    {%- for key, value in environment.items() %}
                                    {"name": "{{ key }}", "value": "{{ value }}"},
                                    {%- endfor %}
                                    {
                                        "name": "JOB_NAME",
                                        "valueFrom": {"fieldRef": {"fieldPath": "metadata.labels['volcano.sh/job-name']"}}
                                    },
                                    {
                                        "name": "ASCEND_VISIBLE_DEVICES",
                                        "valueFrom": {
                                            "fieldRef": {
                                                "fieldPath": "metadata.annotations['huawei.com/Ascend910']"
                                            }
                                        }
                                    }
                                ]
                            }
                        ],
                        "imagePullSecrets": [{"name": "{{ image_secret_key }}"}],
                        "nodeSelector": {"host-arch": "huawei-arm"},
                        "restartPolicy": "Never",
                        "volumes": [
                        {%- for mount in mount_list %}
                            {%- if mount.source.startswith('pvc') %}
                            {"persistentVolumeClaim": {"claimName": "{{ mount.source }}"}, "name": "{{ mount.name }}"},
                            {%- else %}
                            {"hostPath": {"path": "{{ mount.source }}"}, "name": "{{ mount.name }}"},
                            {%- endif %}
                        {%- endfor %}
                            {"emptyDir": {"medium": "Memory", "sizeLimit": "{{ shm }}Gi"}, "name": "shm-data"}
                        ]
                    }
                }
            }
            {%- endif %}
        ]
    }
}"""



npu_volcano_template = env.from_string(_npu_template_str)


if __name__ == "__main__":
    import ast
    import rich

    rendered = npu_volcano_template.render(
        job_name="test-job",
        num_nodes=2,
        submitter="yehaochen",
        max_retry=3,
        cmd="echo hello world",
        image="aha",
        num_cpus=4,
        num_gpus=1,
        memory=16,
        image_secret_key="default-secret",
        mount_list=[{"name": "user1", "source": "user1", "target": "/user1"}, {"name": "user2", "source": "user2", "target": "/user2"}],
        privileged=True,
        priority=1,
    )
    rich.print(rendered)
    # data = ast.literal_eval(rendered)  # 验证渲染结果是合法的 Python 字典 # Python字典中的bool值和json不兼容
    # rich.print(data)
    body = json.loads(rendered)
    rich.print(body)
