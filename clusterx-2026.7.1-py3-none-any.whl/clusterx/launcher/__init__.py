# mypy: disable-error-code="misc,assignment"
import traceback
import sys

from typing_extensions import Type, TypedDict

from clusterx.utils import StrEnum

from .base import BaseCluster, BaseRunParams
from .dlc import AliyunCluster, AliyunPartitionEnum, DLCRunParams

try:
    from .volc import VolcCluster, VolcRunParams
except KeyboardInterrupt as e:
    raise e
except Exception:
    volc_tb = traceback.format_exc()
    VolcCluster = None
    VolcRunParams = None
else:
    volc_tb = None



try:
    from .volc import VolcCluster, VolcRunParams
except KeyboardInterrupt as e:
    raise e
except Exception:
    volc_tb = traceback.format_exc()
    VolcCluster = None
    VolcRunParams = None
else:
    volc_tb = None


try:
    from .brainpp import BrainppRunparams, BrainppCluster, BrainppPartition
except KeyboardInterrupt as e:
    raise e
except Exception:
    brainpp_tb = traceback.format_exc()
    BrainppCluster = None
    BrainppRunparams = None
    BrainppPartition = None
else:
    brainpp_tb = None


ClusterSpec = TypedDict(
    "ClusterSpec",
    {
        "type": Type[BaseCluster] | None,
        "params": Type[BaseRunParams] | None,
        "partition": Type[StrEnum] | None,
        "traceback": str | None,
    },
)


try:
    from .k8s import K8sCluster, K8sPartitionEnum, K8sParams
    k8s_tb = None
except KeyboardInterrupt as e:
    raise e
except Exception:
    k8s_tb = traceback.format_exc()
    K8sCluster = None
    K8sPartitionEnum = None
    K8sParams = None


try:
    from .ssp import SSPCluster, SSPRunParams
    from .ssp.ssp_info import SSPPartition
    ssp_tb = None
except KeyboardInterrupt as e:
    raise e
except Exception:
    ssp_tb = traceback.format_exc()
    SSPCluster = None
    SSPPartition = None
    SSPRunParams = None


CLUSTER_MAPPING = {
    "aliyun": ClusterSpec(type=AliyunCluster, params=DLCRunParams, partition=AliyunPartitionEnum, traceback=None),
    "volc": ClusterSpec(type=VolcCluster, params=VolcRunParams, partition=AliyunPartitionEnum, traceback=volc_tb),
    "yidian": ClusterSpec(type=BrainppCluster, params=BrainppRunparams, partition=BrainppPartition, traceback=brainpp_tb),
    "k8s": ClusterSpec(type=K8sCluster, params=K8sParams, partition=K8sPartitionEnum, traceback=k8s_tb),
    "ssp": ClusterSpec(type=SSPCluster, params=SSPRunParams, partition=SSPPartition, traceback=ssp_tb),
}
