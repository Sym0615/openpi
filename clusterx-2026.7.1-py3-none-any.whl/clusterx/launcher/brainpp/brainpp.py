import re

from brainpp.rjob.client import label_resourcetype

from clusterx.config import BrainppConfig

from ..base import BaseCluster, BaseRunParams, JobSchema, JobStatus, NodeSchema
from .brainpp_info import BrainppPartition
from cyclopts import Parameter
from typing import Annotated, cast
from clusterx.logger import getLogger
from pathlib import Path
import uuid
import asyncio
import json
import os
import re
import time
import typing as T
import uuid
from datetime import datetime, timezone
from pathlib import Path
from typing import Annotated, List, cast

import aiohttp
import requests
from brainpp.rjob import (
    Affinity,
    Job,
    JobStatusType,
    Metadata,
    PrivateMachine,
    Resources,
    RestartPolicy,
    RJobClient,
    Spec,
    Task,
    Template,
    Container,
    utils,
    ImagePullPolicy
)
from brainpp.rjob.struct import k8s_obj_to_rjob
from cyclopts import Parameter
from rich import print
from rich.console import Console
from rich.prompt import Confirm
from rich.table import Column, Table
from pydantic import model_validator
from tenacity import (
    retry,
    retry_if_exception_type, 
    stop_after_attempt,
    wait_fixed,
    RetryError,
)

from clusterx.logger import getLogger

from ..base import (
    BaseCluster,
    BaseRunParams,
    JobSchema,
    JobStatus,
    NodeSchema,
    NodeStatus,
)
from .brainpp_info import BrainppPartition

STATUS_MAPPING = {
    "Created": JobStatus.RUNNING,
    "Restarting": JobStatus.RUNNING,
    "Starting": JobStatus.RUNNING,
    "Running": JobStatus.RUNNING,
    "Killing": JobStatus.RUNNING,
    "Killed": JobStatus.STOPPED,
    "Deleting": JobStatus.STOPPED,
    "Succeeded": JobStatus.SUCCEEDED,
    "Failed": JobStatus.FAILED,
    "Pending": JobStatus.QUEUING,
    "Stopped": JobStatus.STOPPED,
    "Inqueue": JobStatus.QUEUING
}


def _resolve_image_pull_policy_from_string(policy_str: str | None) -> ImagePullPolicy | None:
    if policy_str is None:
        return None

    assert isinstance(policy_str, str), f'Internal Error: policy_str is {policy_str}, should be a string.'

    mapping = {p.name.lower(): p.name for p in ImagePullPolicy}
    # cli help choice: if-not-present -> ifnotpresent
    normalized_policy_str = policy_str.lower().replace("-", "")

    policy = ImagePullPolicy.from_str(mapping.get(normalized_policy_str, normalized_policy_str))
    if policy is None:
        raise ValueError(f"image_pull_policy 参数当前为: {policy_str}，"
                         f"支持的参数有: {', '.join(p.name for p in ImagePullPolicy)}")
    return policy


@Parameter(name="*")
class BrainppRunparams(BaseRunParams[BrainppPartition]):
    delete_exist: Annotated[bool, Parameter(help="是否删除重名的任务")] = False
    mount: Annotated[
        str | None,
        Parameter(help="挂载路径，例如 gpfs+gpfs://gpfs1/chenhaodong:/mnt/chenhaodong,如果有多个挂载路径，请以逗号为分隔符输入"),
    ] = None  # noqa: E501
    image: Annotated[str | None, Parameter(help="镜像 url，默认使用 `~/.config/cluster.yaml` 设置的镜像")] = None
    tmpdir: Annotated[str | None, Parameter(help="任务节点可访问公共目录，默认使用 clusterx.yaml 中的路径")] = None
    project_name: Annotated[str | None, Parameter(help="项目名称，默认使用 clusterx.yaml 中的配置", name=["--project-name"])] = None
    privileged: Annotated[bool, Parameter(help="是否以特权模式运行任务", negative=False)] = False
    image_pull_policy: Annotated[
        ImagePullPolicy | None,
        Parameter(help="镜像拉取策略，默认使用配置文件的设置"),
    ] = None

    @model_validator(mode="before")
    def convert_input(cls, data):
        data = super(BrainppRunparams, cls).convert_input(data)

        if isinstance(data.get("image_pull_policy"), str):
            policy_str: str = data["image_pull_policy"]
            data["image_pull_policy"] = _resolve_image_pull_policy_from_string(policy_str)
        return data

logger = getLogger("clusterx.launcher.brainpp")


class BrainppCluster(BaseCluster):
    """Brainpp 任务发布器，负责创建并提交任务，在提交前检查是否有同名任务."""

    def __init__(self, config: BrainppConfig | None = None):
        """初始化 RJobClient 客户端."""
        from clusterx.config import CLUSTERX_CONFIG, BrainppConfig

        if config is None:
            cluster_cfg = CLUSTERX_CONFIG.yidian
            assert cluster_cfg is not None
            self.clusterx_cfg = cast(BrainppConfig, cluster_cfg)
        else:
            self.clusterx_cfg = config

        self.client = RJobClient(
            cluster_entry="https://h.pjlab.org.cn",
            namespace=self.clusterx_cfg.get("project_name"),
            access_key=self.clusterx_cfg.get("access_key"),
            secret_key=self.clusterx_cfg.get("secret_key"),
        )
    
    def _get_client(self, project_name: str | None = None) -> RJobClient:
        """获取 RJobClient，支持动态 project_name."""
        if project_name is None:
            return self.client
        
        # 如果 project_name 与默认值相同，直接返回默认 client
        default_project_name = self.clusterx_cfg.get("project_name")
        if project_name == default_project_name:
            return self.client
        
        # 创建新的 client
        return RJobClient(
            cluster_entry="https://h.pjlab.org.cn",
            namespace=project_name,
            access_key=self.clusterx_cfg.get("access_key"),
            secret_key=self.clusterx_cfg.get("secret_key"),
        )

    def run(self, run_params: BrainppRunparams) -> JobSchema:
        # TODO: run_params 的 jobname 默认值最好还是为 None，否则无法判断用户是否手动指定了 job_name
        job_name = run_params.job_name

        cmd = self._build_command(run_params.cmd, run_params.no_env)

        if run_params.tmpdir is not None:
            tmpdir = Path(run_params.tmpdir)
        else:
            assert self.clusterx_cfg["tmpdir"], "未在配置文件中发现 tmpdir, 请手工设置"
            tmpdir = Path(self.clusterx_cfg["tmpdir"])

        cmd_name = uuid.uuid4()
        cmd_path = tmpdir / f"{cmd_name}.sh"
        cmd_path.parent.mkdir(parents=True, exist_ok=True)

        with open(cmd_path, "w") as f:
            f.write(cmd)

        if self.clusterx_cfg.get("is_in_workspace") is not None:
            cmd = f"bash {cmd_path}"
            no_packaging = True
            packaging_dir = None
        else:
            cmd = f"cd /workdir/rjob/src && bash {cmd_name}.sh"
            no_packaging = False
            packaging_dir = str(tmpdir)
        image = self._get_image(run_params)
        partition = self._get_partition(run_params)
        mount = self._get_mount(run_params)
        image_pull_policy = self._get_image_pull_policy(run_params)
        job = self._create_job_spec(
            cmd=cmd,
            job_name=job_name,
            image=image,
            num_cpu=run_params.cpus_per_task,
            num_gpu=run_params.gpus_per_task,
            memory_mb=run_params.memory_per_task * 1000,
            preemptible=run_params.preemptible,
            group=partition,
            include_nodes=run_params.include,
            exclude_nodes=run_params.exclude,
            replicas=run_params.num_nodes,
            retry=run_params.retry,
            mount=mount,
            envs=run_params.environment or [],
            priority=run_params.priority,
            privileged=run_params.privileged,
            image_pull_policy=image_pull_policy,
        )

        # 获取 client（支持动态 project_name）
        client = self._get_client(run_params.project_name)
        rjob_name = ""
        try:
            # 提交任务
            rjob_name = client.submit(job, no_packaging=no_packaging, packaging_dir=packaging_dir)
            # 使用相同的 client 获取任务信息
            job_schema = self._get_job_info_with_client(client, rjob_name)
            # logger.info(f"任务 {job_schema.job_name} 创建成功")
            logger.info(job_schema.model_dump_json(indent=4))
            return job_schema
        except Exception as e:
            logger.exception("提交任务失败")
            return JobSchema(
                job_id=rjob_name,
                user="",
                gpus_per_node=run_params.gpus_per_task,
                cpus_per_node=run_params.cpus_per_task,
                memory=str(run_params.memory_per_task),
                status=JobStatus.FAILED,
                num_nodes=run_params.num_nodes,
                partition=run_params.partition,
            )

    def stop(
        self,
        *,
        job_id: str | None = None,
        regex: str | None = None,
        group: str | None = None,
        user: str | None = None,
        partition: BrainppPartition | None = None,
        status: JobStatus | None = None,
        confirm: bool = False,
        check_user: bool = True,
        project_name: str | None = None,
    ) -> None:
        if group is not None:
            raise NotImplementedError("暂不支持按照分组删除任务")

        # 获取 client（支持动态 project_name）
        client = self._get_client(project_name)

        if job_id is not None:
            client.stop(job_id)
            logger.info(f"任务 {job_id} 已停止")
        else:
            jobs = client.list()
            if not jobs:
                logger.info("没有需要被停止的任务")
                return

            filtered_jobs: list[str] = []
            for job in jobs:
                job_user = self._get_job_user(job)
                job_partiton = self._get_job_partition(job)
                job_name = self._get_job_name(job)
                if check_user:
                    if job_user != user:
                        continue
                if partition is not None and job_partiton != partition.name:
                    continue
                if regex is not None and not re.search(regex, job_name):
                    continue
                job_status = self._get_job_status(job)
                if status is not None and job_status != status:
                    continue
                filtered_jobs.append(job_name)

            if not filtered_jobs:
                logger.info("未找到匹配的任务")
                return

            if confirm:
                console = Console()
                confirm_check = Confirm("是否删除以上任务？", console=console)

                table = Table(
                    Column("任务名", min_width=40, max_width=80, overflow="ellipsis"),
                    Column("任务 ID", max_width=20),
                    Column("任务状态", max_width=20),
                    Column("用户名", max_width=20),
                    Column("所属分区", max_width=20),
                )
                for job in filtered_jobs:
                    table.add_row(
                        job["DisplayName"],
                        job["JobId"],
                        job["Status"],
                        job["UserId"],
                        job["WorkspaceName"],
                    )
                console.print(table, highlight=True)

                if not confirm_check.ask():
                    return

            for job in filtered_jobs:
                client.stop(job)

    def stats_node_cli(
        self,
        partition: Annotated[BrainppPartition, Parameter(help="分区名")],
        /,
        *,
        out: Annotated[Path | None, Parameter(name=["--out", "-o"])] = None,
        verbose: Annotated[bool, Parameter(name=["--verbose", "-v"])] = True,
    ):
        """统计分区的节点信息，在底层设置 verbose 和  out 接口是为了方便记录集群相关的完整信息."""
        self.stats_node(partition.value, out=out, verbose=verbose)

    def stats_node(self, /, partition: str, *, out: Path | None = None, verbose=False) -> list[NodeSchema]:
        """统计分区的节点信息."""
        nodes_schema = self._get_stats_node(partition)
        if out is not None:
            out.parent.mkdir(exist_ok=True, parents=True)
            with out.open("w") as f:
                json.dump([n.model_dump() for n in nodes_schema], f, indent=4)

        if verbose:
            # 创建表格显示节点信息
            table = Table(
                Column("节点名", max_width=50),
                Column("状态", max_width=20),
                Column("总 GPU", max_width=20),
                Column("总 CPU", max_width=20),
                Column("总内存(GB)", max_width=20),
            )

            for node in nodes_schema:
                table.add_row(
                    node.name,
                    str(node.status),
                    str(node.total_gpu),
                    str(node.total_cpu),
                    str(node.total_memory),
                )

            print(table)

            # 打印汇总信息
            summarize = Table("总节点数", "正常节点数", "坏节点数", "空闲节点数")
            summarize.add_row(
                str(len(nodes_schema)),
                str(len([n for n in nodes_schema if n.status != NodeStatus.DRAIN])),
                str(len([n for n in nodes_schema if n.status == NodeStatus.DRAIN])),
                str(len([n for n in nodes_schema if n.status == NodeStatus.IDLE])),
            )
            print(summarize)

        return nodes_schema

    def get_node_info(self, /, node: str, *, out: Path | None = None, verbose=False) -> NodeSchema:
        """获取节点详细信息, 在底层设置 verbose 和 out 接口是为了方便集群相关的完整信息."""
        raise NotImplementedError()

    def list_jobs(
        self,
        *,
        group: str | None = None,
        user: str | None = None,
        partition: BrainppPartition | None = None,
        status: JobStatus | None = None,
        regex: str | None = None,
        num: int = 20,
        out: Path | None = None,
        verbose: bool = False,
        project_name: str | None = None
    ) -> list[JobSchema]:
        client = self._get_client(project_name)
        jobs = client.list()

        job_list: list[JobSchema] = []
        for job in jobs:
            job_user = self._get_job_user(job)
            job_partiton = self._get_job_partition(job)
            job_name = self._get_job_name(job)

            if job_user != user:
                continue
            if partition is not None and job_partiton != partition.name:
                continue
            if regex is not None and not re.search(regex, job_name):
                continue
            job_status = self._get_job_status(job)
            if status is not None and job_status != status:
                continue

            clusterx_job = self._get_job_info_with_client(client, job=job)
            job_list.append(clusterx_job)

        if verbose:
            console = Console()

            table = Table(
                Column("任务名", min_width=40, max_width=80, overflow="ellipsis"),
            )
            for job_info in job_list:
                table.add_row(
                    job_info.job_name,
                )
            console.print(table, highlight=True)
            console.print()

        if out is not None:
            out.parent.mkdir(exist_ok=True, parents=True)
            with out.open("w") as f:
                json.dump(job_list, f)

        return job_list

    def _get_job_info_with_client(
            self, client: RJobClient, job_id: str | None = None, job: Job | None = None, verbose=False
    ) -> JobSchema:
        """使用指定的 client 获取任务信息."""
        assert (job_id is None) != (job is None)

        def get_replicas(_job_id):
            replicas_obj = client.api.list_namespaced_custom_object(
                group=client.group,
                version=client.version,
                namespace=client.namespace,
                plural="replicas",
                label_selector=f"rjob.brainpp.cn/rjob-name={_job_id}",
            )
            return replicas_obj.get("items", [])
        if job is None:
            jobs_job = client.api.list_namespaced_custom_object(
                group=client.group,
                version=client.version,
                namespace=client.namespace,
                plural=client.plural,
                label_selector=f"rjob.brainpp.cn/rjob-name={job_id}",
            )
            jobs = jobs_job["items"]
            if jobs is None or len(jobs) == 0:
                raise RuntimeError(f"Cannot find {job_id}")
            if len(jobs) != 1:
                raise RuntimeError("ClusterX Internal Error! found duplicate jobs!")
            job = jobs[0]
            replicas = get_replicas(job_id)
            job = k8s_obj_to_rjob(
                job,
                replicas,
            )
        else:
            job_id = job.job_labels()["rjob.brainpp.cn/rjob-name"]
            replicas = get_replicas(job_id)

        job_dict = job.to_dict()
        tasks = job_dict["spec"]["tasks"]
        assert len(tasks) == 1, "暂时不支持多任务 job 的获取"
        task = next(iter(tasks.values()))
        resources = task["template"]["containers"][0]["resources"]
        # metadata = self._get_replica_metadata(job_id)
        # print(metadata)
        node_ips = []
        nodes = []
        node_indexes = []
        for item in replicas:
            if "podIP" in item["status"]:
                node_ips.append(item["status"]["podIP"])
            else:
                node_ips.append("none")

            if "nodeName" in item["status"]:
                nodes.append(item["status"]["nodeName"])
            else:
                nodes.append("none")

            if item.get("metadata", {}).get("annotations", {}).get("kubebrain.brainpp.cn/replica-index") is not None:
                node_indexes.append(int(item["metadata"]["annotations"]["kubebrain.brainpp.cn/replica-index"]))
            else:
                node_indexes.append(100000)

        node_ips = [ip for _, ip in sorted(zip(node_indexes, node_ips))]
        nodes = [node for _, node in sorted(zip(node_indexes, nodes))]

        job_schema = JobSchema(
            job_id=job_id,  # 或许可以替换成 k8s create id？
            user=self._get_job_user(job),
            gpus_per_node=resources["gpu"],
            cpus_per_node=resources["cpu"],
            memory=f"{resources['memoryInMB'] // 1024:.3f}G",
            status=self._get_job_status(job),
            num_nodes=task["replicas"],
            partition=self._get_job_partition(job),
            job_name=job_id,
            cmd=" ".join(task["template"]["command"]),
            nodes=nodes,
            nodes_ip=node_ips,
        )
        if verbose:
            print(job_schema)
        return job_schema

    def get_job_info(self, /, job_id: str, verbose=False, project_name: str | None = None) -> JobSchema:
        # 获取 client（支持动态 project_name）
        client = self._get_client(project_name)
        return self._get_job_info_with_client(client, job_id, verbose=verbose)

    def get_log(self, job_id: str, lines: int | None = None, partition: str | None = None) -> str:
        logs = asyncio.run(self.async_get_log(job_id, lines=lines, partition=partition))
        if logs is None:
            raise RuntimeError(
                f"获取日志失败：返回数据为 None。"
                f"这可能是因为 project_name 或 partition 未正确设置，或者任务 {job_id} 不存在。"
                f"当前使用的 namespace: {self.client.namespace}, partition: {partition}"
            )
        # async_get_log 返回字符串，直接返回
        if isinstance(logs, str):
            return logs
        # 如果返回的是列表（不应该发生，但为了兼容性保留）
        if isinstance(logs, list):
            return "\n".join(i["line"] if isinstance(i, dict) and "line" in i else str(i) for i in logs)
        return str(logs)

    async def async_get_job_info(self, /, job_id: str, verbose=False) -> JobSchema:
        raise NotImplementedError()

    def run_cli(
        self, *cmd: Annotated[str, Parameter(allow_leading_hyphen=True)], run_params: BrainppRunparams | None = None
    ) -> JobSchema:
        if run_params is None:
            run_params = BrainppRunparams()
        run_params.cmd = " ".join(cmd)
        return self.run(run_params)

    def list_cli(
        self,
        *,
        group: str | None = None,
        user: Annotated[str | None, Parameter(name=["--user", "-u"])] = None,
        partition: Annotated[BrainppPartition | None, Parameter(name=["-p", "--partition"])] = None,
        status: Annotated[JobStatus | None, Parameter(name=["--status", "-s"])] = None,
        regex: Annotated[str | None, Parameter(help="匹配任务名的正则表达式")] = None,
        num: Annotated[int, Parameter(help="匹配任务名的正则表达式")] = 20,
        out: Annotated[Path | None, Parameter(name=["--out", "-o"])] = None,
        verbose: Annotated[bool, Parameter(name=["--verbose", "-v"])] = True,
    ):
        return self.list_jobs(
            group=group,
            user=user,
            partition=partition,
            status=status,
            regex=regex,
            num=num,
            out=out,
            verbose=verbose,
        )

    def stop_cli(
        self,
        *,
        job_id: Annotated[str | None, Parameter(name=["--job-id", "-j"])] = None,
        regex: Annotated[str | None, Parameter(help="匹配任务名的正则表达式")] = None,
        group: Annotated[str | None, Parameter(name=["--group", "-g"])] = None,
        user: Annotated[str | None, Parameter(name=["--user", "-u"])] = None,
        partition: Annotated[BrainppPartition | None, Parameter(name=["-p", "--partition"])] = None,
        status: Annotated[JobStatus | None, Parameter(name=["-status", "-s"])] = None,
        confirm: Annotated[bool, Parameter(name=["--confirm", "-c"])] = False,
        check_user: bool = True,
    ) -> None:
        self.stop(job_id=job_id, regex=regex, group=group, user=user, partition=partition, confirm=confirm, check_user=check_user)

    def _create_job_spec(
        self,
        cmd: str,
        job_name: str,
        image: str,
        num_cpu: int,
        num_gpu: int,
        memory_mb: int,
        preemptible: bool | None,
        group: str,
        include_nodes: str | None,
        exclude_nodes: str | None,
        replicas: int,
        retry: bool,
        mount: list[str] | None,
        envs: list[str],
        priority: int | None = None,
        privileged: bool = False,
        image_pull_policy: ImagePullPolicy = ImagePullPolicy.IfNotPresent,
    ):
        """创建任务规范.

        参数:
            cmd: 执行命令
            job_name: 任务名称
            image: 容器镜像
            num_cpu: CPU 数量
            num_gpu: GPU 数量
            memory_mb: 内存大小（MB）
            preemptible: 是否可抢占
            group: 分组名称
            include_nodes: 指定节点列表
            exclude_nodes: 排除节点列表
            replicas: 副本数量
            retry: 是否重试
            mount: 挂载路径列表
            envs: 环境变量列表
            priority: 任务优先级
            privileged: 是否以特权模式运行任务

        返回:
            Job 对象
        """
        # 创建亲和性配置
        include_nodes_list = self._normalize_node_list(include_nodes)
        exclude_nodes_list = self._normalize_node_list(exclude_nodes)
        affinity = Affinity(positive_tags=include_nodes_list, negative_tags=exclude_nodes_list)
        metadata_name, _ = utils.validate_and_normalize_to_k8s_name(job_name)

        if replicas > 1:
            custom_resources = ["rdma/mlnx_shared=8", "mellanox.com/mlnx_rdma=1"] if num_gpu > 0 else []
            environment = {
                "DISTRIBUTED_JOB": "true",
            }
            gang_start = num_gpu > 0
        else:
            custom_resources = None
            environment = {
                "DISTRIBUTED_JOB": "true",
            }
            gang_start = False

        for env_str in envs:
            key, value = env_str.split("=", 1)
            environment[key] = value

        if retry:
            restart_policy = RestartPolicy.RestartJobOnFailure
        else:
            restart_policy = RestartPolicy.Never

        # 创建任务模板
        task_name = "task"
        template = Template(
            containers=[
                Container(
                    name=task_name,
                    image=image,
                    command=["bash", "-ecx", f"{cmd}"],
                    resources=Resources(
                        cpu=num_cpu,
                        gpu=num_gpu,
                        memory_in_mb=memory_mb,
                        custom_resources=custom_resources,
                    ),
                    requests=Resources(
                        cpu=num_cpu,
                        gpu=num_gpu,
                        memory_in_mb=memory_mb,
                        custom_resources=custom_resources,
                    ),
                    environments=environment,
                    privileged=privileged,
                    image_pull_policy=image_pull_policy,
                )
            ],
            mount=mount,
        )

        if preemptible:
            # 闲时的模板
            metadata = Metadata(
                name=metadata_name,
                labels={
                    "rjob.brainpp.cn/zs-task-type": "rjob-idle",
                    "quotagroup.brainpp.cn/quotagroup": "",
                },
                annotations={
                    "volcano.brainpp.cn/priority": str(priority),
                },
            )
            group = ""
        else:
            metadata = Metadata(
                name=metadata_name,
                charged_group=group,
                annotations={
                    "volcano.brainpp.cn/priority": str(priority),
                },
            )

        # 创建任务规范
        rjob_spec = Spec(
            affinity=affinity,
            preemptible="yes" if preemptible else None,
            group=group,
            gang_start=gang_start,
            host_network=num_gpu == 8,  # `host_network` is only allowed to be true for 8gpus task in brainpp
            tasks={
                task_name: Task(
                    replicas=replicas,
                    restart_policy=restart_policy,
                    private_machine=PrivateMachine.Group,
                    template=template,
                    # max_running_duration=task_config["max_running_duration"],
                ),
            },
        )

        # 创建Job对象
        job = Job(
            metadata=metadata,
            spec=rjob_spec,
        )

        return job

    def _get_stats_node(self, partition: str) -> list[NodeSchema]:
        """统计分区的节点信息."""
        # 构建 API URL
        url = f"{self.client.cluster_entry}/kapis/node.brainpp.cn/v1alpha1/nodes/details"
        params = {
            "tenant": self.client.namespace.split("-")[0],  # 从 namespace 中提取 tenant
            "project": self.client.namespace,  # project 就是 namespace
            "group": partition,  # 使用分区名作为 group
            "pageSize": 1000000, # 单页1000000节点，避免分页多次请求
        }

        # 创建认证
        auth = (self.client.username, self.client.password)
        
        # 使用 requests 发送同步请求
        response = requests.get(
            url, 
            params=params, 
            verify=self.client.verifyssl,
            auth=auth,
            timeout=30
        )
        
        if response.status_code != 200:
            raise RuntimeError(f"获取节点信息失败: HTTP {response.status_code}")
        
        data = response.json()

        if data["status"] != "Success":
            raise RuntimeError(f"获取节点信息失败: {data['status']}")

        nodes_info = data["data"]["machines"]
        nodes_schema: list[NodeSchema] = []

        for node_info in nodes_info:
            # 获取节点状态
            node_status = NodeStatus.UNRECORGNIZED
            for condition in node_info["status"]["conditions"]:
                if condition["type"] == "Ready":
                    if node_info["metadata"]["labels"]["node.brainpp.cn/maintenance"] == "true":
                        node_status = NodeStatus.DRAIN
                    elif condition["status"] == "True":
                        used = node_info["used"]
                        if int(used["cpu"]) > 0 or int(used["memory"]) > 0 or int(used["nvidia.com/gpu"]) > 0:
                            node_status = NodeStatus.MIXED
                        else:
                            node_status = NodeStatus.IDLE
                    break

            # 提取节点信息
            name = node_info["metadata"]["name"]
            capacity = node_info["status"]["capacity"]

            # 获取 GPU 数量
            total_gpu = int(capacity.get("nvidia.com/gpu", "0"))

            # 获取 CPU 数量
            total_cpu = int(capacity.get("cpu", "0"))

            # 获取内存大小（转换为 GB）
            total_memory: str
            memory_literal = cast(str, capacity.get("memory", "0Ki"))

            if memory_literal.endswith("Ki"):
                memory_ki = memory_literal.rstrip("Ki")
                total_memory = f"{int(memory_ki) // (1024 * 1024)}"  # 转换为 GB
            elif memory_literal.endswith("Mi"):
                memory_mb = memory_literal.rstrip("Mi")
                total_memory = f"{int(memory_mb) // 1024}"
            else:
                total_memory = memory_literal  # Let's trust the fall-back value to be in GB ;)

            node_schema = NodeSchema(
                name=name,
                status=node_status,
                total_gpu=total_gpu,
                total_cpu=total_cpu,
                total_memory=total_memory,
            )
            nodes_schema.append(node_schema)
        return nodes_schema

    def _get_replica_node_map(self, job: Job) -> dict[str, str]:
        """获取任务中所有副本的节点映射.

        参数:
            job_name: 任务名称

        返回:
            副本ID到节点名称的映射字典
        """
        replica_node_map = {}

        if job.spec and job.spec.tasks:
            for task in job.spec.tasks.values():
                if task.replicaStatus:
                    for rs in task.replicaStatus:
                        if rs.process_id is not None and rs.process_id != "":
                            replica_node_map[rs.process_id] = rs.node_name
        return replica_node_map

    def _get_replica_metadata(self, rjob_name: str) -> dict:
        replica = self.client.api.get_namespaced_custom_object(
            group=self.client.group,
            version=self.client.version,
            namespace=self.client.namespace,
            plural="rjob",
            name=rjob_name,
        )
        return replica["metadata"]

    def _get_job_user(self, job: Job) -> str:
        labels = job.metadata.labels
        if labels is None:
            return "Unknown"
        else:
            return labels["kubebrain.brainpp.cn/creator"]

    def _get_job_partition(self, job: Job) -> str:
        spec = job.spec
        if spec is None:
            return "Unknown"
        partition = spec.group
        return partition or "Unknown"

    def _get_job_name(self, job: Job) -> str:
        metadata = job.metadata
        if metadata is None:
            return "Unknown"
        name = metadata.name
        return name or "Unknown"

    def _get_job_status(self, job: Job) -> JobStatus:
        orig_status = job.status.current.name
        return STATUS_MAPPING[orig_status]

    def _build_pytorch_ddp_cmd(self):
        cmd = (
            "export MASTER_ADDR=$MASTER_ADDR\n"
            "export MASTER_PORT=6000\n"
            "export WORLD_SIZE=$NODE_COUNT\n"
            "export RANK=$NODE_RANK\n"
        )
        return cmd

    def _build_command(self, cmd: str, no_env: bool) -> str:
        _cmd = self._build_pytorch_ddp_cmd()
        exclude = {"LC_ALL"}
        if not no_env:
            env_cmd = ""
            inherited_env = {k: v for k, v in os.environ.items() if v != ""}
            for k, v in inherited_env.items():
                if k in exclude:
                    continue
                env_cmd += f"export {k}='{v}'\n"
            _cmd += env_cmd
            _cmd += f"cd {os.getcwd()}\n"
        cmd = _cmd + cmd
        return cmd

    def _get_image(self, run_params: BrainppRunparams) -> str:
        image = run_params.image or self.clusterx_cfg["image"]
        if not image:
            raise RuntimeError("请设置镜像地址")
        return image

    def _get_partition(self, run_params: BrainppRunparams) -> str:
        partition = run_params.partition or self.clusterx_cfg["partition"]

        if not partition:
            raise RuntimeError("请设置分区名")
        return partition

    def _get_mount(self, run_params: BrainppRunparams) -> list[str] | None:
        default_mount = self.clusterx_cfg["mount"].copy()
        if run_params.mount is not None:
            default_mount += run_params.mount.split(",")
        return default_mount

    def _get_image_pull_policy(self, run_params: BrainppRunparams) -> ImagePullPolicy:
        """获取镜像拉取策略.

        优先级: 命令行参数 > 配置文件 > IfNotPresent(默认)
        """
        policy = None
        if run_params.image_pull_policy is not None:
            policy = run_params.image_pull_policy
        else:
            policy_str = self.clusterx_cfg.get("image_pull_policy", None)
            policy = _resolve_image_pull_policy_from_string(policy_str)

        if policy is None:
            policy = ImagePullPolicy.IfNotPresent
        return policy

    def _normalize_node_list(self, nodes: str | None) -> list[str]:
        """将节点字符串转换为标准化的节点列表.

        参数:
            nodes: 逗号分隔的节点字符串，例如 "node1,node2,node3"

        返回:
            标准化后的节点列表，每个节点名称都带有 "node/" 前缀
        """
        if not nodes:
            return []
        
        return [
            f"node/{node}" if not node.startswith("node/") else node 
            for node in nodes.split(",") 
            if node
        ]

    async def async_get_log(
        self,
        job_id: str,
        lines: int | None = None,
        replicas: T.Optional[List[str]] = None,
        partition: str | None = None,
    ):
        """获取任务副本的日志（异步版本）.

        参数:
            job_id: 任务 ID
            lines: 只显示最近的 n 行日志，如果不指定则显示全部（可选）
            replicas: 副本列表（可选）
            partition: 分区名称（可选）

        返回:
            日志内容
        """
        if self.client.type == "kubebrain":
            logs = await self._async_kubebrain_logs_rjob(
                name=job_id,
                replicas=replicas,
                partition=partition,
                lines=lines,
            )
            return logs
        else:
            raise RuntimeError("async_logs_rjob method only for kubebrain platform!")

    @retry(
        stop=stop_after_attempt(3),
        wait=wait_fixed(1),
        retry=retry_if_exception_type((aiohttp.ClientError, RuntimeError)),
    )
    async def _async_kubebrain_logs_rjob(
        self,
        name: str,
        replicas: T.Optional[List[str]] = None,
        partition: str | None = None,
        lines: int | None = None,
    ) -> list:
        """获取 kubebrain 平台任务的日志.

        参数:
            name: 任务名称
            replicas: 副本列表
            partition: 分区名称（可选）
            lines: 只显示最近的 n 行日志，如果不指定则显示全部（可选）

        返回:
            日志内容列表
        """
        tenants = self.client.namespace.split("-")[0]
        rjob_endpoint = "{}/kapis/{}/v1alpha1/tenants/{}/projects/{}".format(
            self.client.cluster_entry, self.client.group, tenants, self.client.namespace
        )

        async with await self._create_brainpp_api_session() as session:
            # 检查 rjob 是否存在并获取 replicas
            uri = "{}/rjobs/{}/infos".format(
                rjob_endpoint,
                name,
            )
            params = {}
            if partition is not None:
                params["group"] = partition
            async with session.get(url=uri, ssl=self.client.verifyssl, params=params) as response:
                if response.status >= 400:
                    raise RuntimeError(f"获取rjob信息失败: HTTP {response.status}")
                rjob_data = await response.json()
                if rjob_data["data"] is None or rjob_data["data"] == {}:
                    raise RuntimeError(f"获取rjob信息失败，replicas为空")
                
            replicas_list = []
            for task in rjob_data["data"]:
                replicas_list.extend(rjob_data["data"][task])

            if replicas is not None and len(replicas) > 0:
                replicas_list = replicas

            if len(replicas_list) == 0:
                raise RuntimeError(
                    f"获取rjob信息失败，replicas列表为空。"
                    f"这可能是因为 partition 未正确设置。"
                    f"当前使用的 namespace: {self.client.namespace}, partition: {partition}"
                )

            creation_time = datetime.now(timezone.utc)
            for replica_name in replicas_list:
                replica = self.client.api.get_namespaced_custom_object(
                    group=self.client.group,
                    version=self.client.version,
                    namespace=self.client.namespace,
                    plural="replicas",
                    name=replica_name,
                )
                replica_creation_time = datetime.strptime(
                    replica["metadata"]["creationTimestamp"], "%Y-%m-%dT%H:%M:%SZ"
                ).replace(tzinfo=timezone.utc)
                if replica_creation_time < creation_time:
                    creation_time = replica_creation_time

            uri = "{}/kapis/{}/{}/tenants/{}/projects/{}/rjobs/{}/logs/query_range".format(
                self.client.cluster_entry,
                self.client.group,
                self.client.version,
                self.client.namespace.split("-")[0],
                self.client.namespace,
                name,
            )
            # 后端网关对 direction=backward 的 query_range 一律在 ~15s 后返回 504（与 limit、时间
            # 窗口大小无关，实测即使只查最近 1 分钟、limit=10 也超时），唯有 direction=forward 能稳定
            # 返回。因此只能正向（旧→新）翻页：从 job 起点开始，按时间游标分页向后读，读完后再截取最新
            # total_limit 行。无法借助后端做服务端 tail，要拿最新若干行就必须正向扫到末尾。
            base_params = {"replicas": replicas_list, "direction": "forward"}
            if partition is not None:
                base_params["group"] = partition

            # maximum is 100000. if more than 100000, it will get an error.
            total_limit = min(lines, 100000) if lines is not None and lines > 0 else 100000
            start_ns = int(creation_time.timestamp() * 1e9)
            end_ns = int(time.time_ns())

            # 单页 limit 过大同样会触发网关 504（实测 5000 约 4s 可返回，10000 即超时），故每页固定
            # 取 5000 条；start 含、end 不含，Loki 按时间升序返回（最旧在前）。
            page_size = 5000
            logs: list = []
            cursor_start = start_ns
            while cursor_start < end_ns:
                params = base_params | {
                    "start": str(cursor_start),
                    "end": str(end_ns),
                    "limit": page_size,
                }
                async with session.get(url=uri, ssl=self.client.verifyssl, params=params) as response:
                    if response.status >= 400:
                        response_text = await response.text()
                        raise RuntimeError(f"获取日志失败: HTTP {response.status}, 响应: {response_text}")
                    data = await response.json()
                batch = data["data"] or []
                if not batch:
                    break
                logs.extend(batch)
                # 不足一页说明已读到末尾。
                if len(batch) < page_size:
                    break
                # 下一页 start 设为本页最新时间戳 +1ns（start 含），避免重复读取边界条目。同一纳秒内
                # 出现超过一页（5000 行）日志才会丢边界条目，实际不可能发生。
                cursor_start = max(int(entry["timestamp"]) for entry in batch) + 1
            return logs[-total_limit:]

    async def _log_threading(self, job_id):
        """异步获取日志的生成器.

        参数:
            job_id: 任务 ID

        生成:
            每次产生新的日志行
        """
        prev_logs = ""

        while True:
            try:
                cur_logs = await self.async_get_log(job_id)
                increment_logs = cur_logs[len(prev_logs) :]
            except RetryError as e:
                # RetryError 包装了原始异常
                original_exception = e.last_attempt.exception()
                yield(f"获取日志失败，请检查{job_id}是否存在 -> {original_exception}")
                break

            if not increment_logs:
                continue

            prev_logs = cur_logs
            for line in increment_logs:
                yield line["line"]

    async def _create_brainpp_api_session(self) -> aiohttp.ClientSession:
        """创建一个带有认证的 aiohttp session.

        返回:
            配置好的 session 对象
        """
        # 创建连接器配置
        connector = aiohttp.TCPConnector(
            limit_per_host=10,  # 每个主机的连接限制
        )
        # 设置超时配置
        timeout = aiohttp.ClientTimeout(total=30)  # 30秒超时
        # 创建认证
        auth = aiohttp.BasicAuth(self.client.username, self.client.password)
        # 创建并返回 session
        return aiohttp.ClientSession(connector=connector, timeout=timeout, auth=auth)
